# AI生成
#!/usr/bin/env python3
"""V3训练后自动流水线：复制权重 → 阈值调优 → 更新配置 → 重新推理 → 对比报告

用法:
    python post_train_pipeline.py

前置条件: V3训练已完成，work/runs/train_v3/weights/best.pt 存在
"""
import shutil
import subprocess
import sys
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CODE = ROOT / "code"
WORK = ROOT / "work"
RESULT = ROOT / "result"


def run(cmd: str, cwd: Path | None = None) -> tuple[int, str]:
    """运行命令并返回 (returncode, output)"""
    print(f"\n{'='*60}")
    print(f"▶ {cmd}")
    print(f"{'='*60}")
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=cwd or CODE,
            capture_output=True, text=True, timeout=10800
        )
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout or ""
        if isinstance(out, bytes):
            out = out.decode("utf-8", errors="ignore")
        print("[timeout] 命令超过 3 小时仍未完成，已中止该步骤")
        return 1, out
    output = result.stdout + result.stderr
    print(output[-2000:] if len(output) > 2000 else output)
    return result.returncode, output


def main():
    # Step 1: 检查V3权重
    v3_best = WORK / "runs" / "train_v3" / "weights" / "best.pt"
    if not v3_best.exists():
        print("❌ V3训练未完成：work/runs/train_v3/weights/best.pt 不存在")
        sys.exit(1)

    # 检查训练是否真的完成了（至少5个epoch）
    log_file = WORK / "train_v3.log"
    if log_file.exists():
        completed_epochs = 0
        for line in log_file.read_text(errors="ignore").splitlines():
            if line.strip().startswith("all") and "541" in line:
                completed_epochs += 1
        print(f"📊 V3训练已完成 {completed_epochs} 个epoch")
        if completed_epochs < 5:
            print(f"⚠️ 训练可能未完成（仅{completed_epochs}轮），建议等待更多epoch")
            resp = input("是否继续？(y/n): ").strip().lower()
            if resp != "y":
                sys.exit(0)

    # Step 1.6: 备份当前 result.json（V2 结果），避免被 V3 覆盖后无法回退
    result_file = RESULT / "result.json"
    v2_result = RESULT / "result_v2_tuned.json"
    if result_file.exists() and not v2_result.exists():
        shutil.copy2(result_file, v2_result)
        print(f"✅ V2 结果已备份: {v2_result.name}")

    # Step 2: 备份V2权重，复制V3权重
    v2_best = CODE / "models" / "best.pt"
    v2_backup = CODE / "models" / "best_v2.pt"
    if v2_best.exists() and not v2_backup.exists():
        shutil.copy2(v2_best, v2_backup)
        print(f"✅ V2权重已备份: {v2_backup.name}")

    shutil.copy2(v3_best, v2_best)
    print(f"✅ V3权重已复制到: models/best.pt ({v2_best.stat().st_size / 1024 / 1024:.1f}MB)")

    # Step 3: 阈值调优
    print("\n🔧 Step 3: 阈值调优...")
    rc, _ = run("python tune_thresholds.py --model ../work/runs/train_v3/weights/best.pt --output ../work/tuned_thresholds_v3.json")
    if rc != 0:
        print("⚠️ 阈值调优失败，使用默认阈值继续")

    # Step 4: 读取调优阈值并更新common.py
    tuned_file = WORK / "tuned_thresholds_v3.json"
    if tuned_file.exists():
        tuned = json.loads(tuned_file.read_text())
        print(f"✅ 调优阈值: {json.dumps(tuned, ensure_ascii=False, indent=2)}")

        # 更新 common.py 中的 PER_CLASS_CONF
        common_file = CODE / "common.py"
        content = common_file.read_text(encoding="utf-8")
        # 构建新的阈值字典文本
        conf_lines = []
        for cls_name, threshold in tuned.items():
            conf_lines.append(f'    "{cls_name}": {threshold},')
        new_conf = "PER_CLASS_CONF = {\n" + "\n".join(conf_lines) + "\n}"

        # 替换旧的 PER_CLASS_CONF 块
        import re
        content = re.sub(
            r'PER_CLASS_CONF\s*=\s*\{[^}]+\}',
            new_conf,
            content
        )
        common_file.write_text(content, encoding="utf-8")
        print("✅ common.py 阈值已更新")

    # Step 4.5: 推理策略对比实验（选出最优 imgsz / TTA 配置）
    print("\n🧪 Step 4.5: 推理策略对比实验（验证集）...")
    best_imgsz, best_augment = 416, False
    exp_file = WORK / "inference_experiments.json"
    rc, _ = run("python experiment_inference.py --model ../work/runs/train_v3/weights/best.pt")
    if rc == 0 and exp_file.exists():
        try:
            exp = json.loads(exp_file.read_text())
            best = exp.get("best", {})
            best_imgsz = int(best.get("imgsz", 416))
            best_augment = bool(best.get("augment", False))
            print(f"🏆 最优推理配置: imgsz={best_imgsz}, augment={best_augment} (mAP50={best.get('mAP50')})")
        except Exception as exc:  # noqa: BLE001
            print(f"⚠️ 解析实验结果失败，使用默认 416: {exc}")
    else:
        print("⚠️ 实验未产出结果，使用默认 imgsz=416")

    # Step 5: 重新推理（使用实验选出的最优配置）
    print(f"\n🔍 Step 5: 重新推理3251张测试图（imgsz={best_imgsz}, augment={best_augment}）...")
    aug_flag = " --augment" if best_augment else ""
    rc, output = run(
        f"python predict.py --model ../work/runs/train_v3/weights/best.pt "
        f"--out ../result/result.json --name v3 --imgsz {best_imgsz}{aug_flag}"
    )
    if rc != 0:
        print("❌ 推理失败！")
        sys.exit(1)

    # Step 6: 统计结果
    result_file = RESULT / "result.json"
    if result_file.exists():
        results = json.loads(result_file.read_text())
        total = len(results)
        detected = sum(1 for r in results if r.get("objects"))
        total_objects = sum(len(r.get("objects", [])) for r in results)
        classes = set()
        for r in results:
            for o in r.get("objects", []):
                classes.add(o.get("category", ""))
        print(f"\n{'='*60}")
        print(f"📊 V3推理结果统计")
        print(f"{'='*60}")
        print(f"  总图片数: {total}")
        print(f"  有检测图片: {detected} ({detected/total*100:.1f}%)")
        print(f"  总检测框数: {total_objects}")
        print(f"  覆盖类别数: {len(classes)}/12")
        print(f"  类别列表: {sorted(classes)}")

    # Step 7: 对比V2结果
    v2_result = RESULT / "result_v2_tuned.json"
    if v2_result.exists():
        v2_results = json.loads(v2_result.read_text())
        v2_detected = sum(1 for r in v2_results if r.get("objects"))
        v2_objects = sum(len(r.get("objects", [])) for r in v2_results)
        print(f"\n📈 V2 vs V3 对比:")
        print(f"  V2: {v2_detected}张有检测, {v2_objects}框")
        print(f"  V3: {detected}张有检测, {total_objects}框")
        print(f"  检测提升: {detected-v2_detected:+d}张 ({(detected-v2_detected)/v2_detected*100:+.1f}%)")
        print(f"  框数提升: {total_objects-v2_objects:+d} ({(total_objects-v2_objects)/v2_objects*100:+.1f}%)")

    print(f"\n✅ V3流水线完成！")


if __name__ == "__main__":
    main()
