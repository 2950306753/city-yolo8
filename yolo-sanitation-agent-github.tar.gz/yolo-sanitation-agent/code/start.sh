# AI生成
#!/usr/bin/env bash
# AI生成
# 启动市容环卫智能体 Web 服务（Linux / macOS）
set -euo pipefail
cd "$(dirname "$0")"

echo "==> 启动智能体 Web 服务"
python start.py "$@"