# AI生成
"""将 train_set/label/label.json 转换为 YOLO 训练数据集。

产出 work/dataset/ 结构：
    images/train/*.jpg   labels/train/*.txt
    images/val/*.jpg     labels/val/*.txt
    data.yaml
"""
from __future__ import annotations

import json
import os
import random
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import CLASS_TO_ID, TRAIN_IMAGE_DIR, TRAIN_LABEL, WORK_DIR, normalize_bbox  # noqa: E402


def main(val_ratio: float = 0.1, seed: int = 42) -> str:
    random.seed(seed)
    records = json.load(open(TRAIN_LABEL, encoding="utf-8"))

    ds = os.path.join(WORK_DIR, "dataset")
    for split in ("train", "val"):
        os.makedirs(os.path.join(ds, "images", split), exist_ok=True)
        os.makedirs(os.path.join(ds, "labels", split), exist_ok=True)

    usable = []
    skipped_img = 0
    skipped_box = 0
    for rec in records:
        fn = rec["filename"]
        src = os.path.join(TRAIN_IMAGE_DIR, fn)
        if not os.path.isfile(src):
            skipped_img += 1
            continue
        w, h = rec.get("image_width"), rec.get("image_height")
        if not w or not h:
            skipped_img += 1
            continue
        lines = []
        for obj in rec.get("objects", []):
            cat = obj.get("category", "")
            if cat not in CLASS_TO_ID:  # 过滤空类别/未知类别
                skipped_box += 1
                continue
            cx, cy, bw, bh = normalize_bbox(obj["bbox"], w, h)
            if bw <= 0 or bh <= 0:
                skipped_box += 1
                continue
            lines.append(f"{CLASS_TO_ID[cat]} {cx:.6f} {cy:.6f} {bw:.6f} {bh:.6f}")
        usable.append((fn, lines))

    random.shuffle(usable)
    n_val = max(1, int(len(usable) * val_ratio))
    val_set, train_set = usable[:n_val], usable[n_val:]

    def dump(items, split):
        for fn, lines in items:
            shutil.copyfile(os.path.join(TRAIN_IMAGE_DIR, fn), os.path.join(ds, "images", split, fn))
            stem = os.path.splitext(fn)[0]
            with open(os.path.join(ds, "labels", split, stem + ".txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(lines))

    dump(train_set, "train")
    dump(val_set, "val")

    yaml_path = os.path.join(ds, "data.yaml")
    with open(yaml_path, "w", encoding="utf-8") as f:
        f.write(f"path: {ds}\n")
        f.write("train: images/train\n")
        f.write("val: images/val\n")
        f.write(f"nc: {len(CLASS_TO_ID)}\n")
        f.write("names:\n")
        for name, idx in sorted(CLASS_TO_ID.items(), key=lambda kv: kv[1]):
            f.write(f"  {idx}: {name}\n")

    print(f"[dataset] train={len(train_set)} val={len(val_set)} "
          f"skip_img={skipped_img} skip_box={skipped_box}")
    print(f"[dataset] data.yaml -> {yaml_path}")
    return yaml_path


if __name__ == "__main__":
    main()
