"""混合策略：以75分结果为底座，补充YOLOv8l v3的高置信度增量检测"""
import json

BASE_PATH = '/root/result10141757.json'          # 75分底座
INCR_PATH = '/root/cloud_train_pack/result/result_v8l_fast.json'  # 新模型结果
OUTPUT_PATH = '/root/final_submission.json'

CONF_MIN = 0.5      # 增量框的最低置信度
IOU_MAX = 0.3       # 与现有框重叠超过此值则不补充


def iou(a, b):
    """a/b 均为 [x1, y1, w, h]"""
    ax1, ay1, aw, ah = a
    bx1, by1, bw, bh = b
    ax2, ay2 = ax1 + aw, ay1 + ah
    bx2, by2 = bx1 + bw, by1 + bh
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    inter = max(0, ix2 - ix1) * max(0, iy2 - iy1)
    union = aw * ah + bw * bh - inter
    return inter / union if union > 0 else 0


with open(BASE_PATH) as f:
    base = json.load(f)
with open(INCR_PATH) as f:
    incr = json.load(f)

incr_by_name = {d['filename']: d for d in incr}

n_added_boxes = 0
n_added_images = 0
n_empty_filled = 0

for d in base:
    fn = d['filename']
    src = incr_by_name.get(fn)
    if src is None:
        continue
    existing = d.get('objects', [])
    was_empty = len(existing) == 0
    added = 0
    for o in src.get('objects', []):
        if o['score'] < CONF_MIN:
            continue
        overlap = any(
            o['category'] == e['category'] and iou(o['bbox'], e['bbox']) >= IOU_MAX
            for e in existing
        )
        if overlap:
            continue
        existing.append(o)
        added += 1
    if added > 0:
        n_added_boxes += added
        n_added_images += 1
        if was_empty:
            n_empty_filled += 1
        # 同步更新 image_label
        seen = []
        for o in existing:
            if o['category'] not in seen:
                seen.append(o['category'])
        d['image_label'] = seen if seen else ['正常']

with open(OUTPUT_PATH, 'w', encoding='utf-8') as f:
    json.dump(base, f, ensure_ascii=False, indent=2)

n_boxes = sum(len(d.get('objects', [])) for d in base)
n_obj_img = sum(1 for d in base if d.get('objects'))

print('=' * 50)
print('混合策略合并完成！')
print(f'  输出文件: {OUTPUT_PATH}')
print(f'  图像总数: {len(base)}')
print(f'  有目标图像: {n_obj_img} (原1963)')
print(f'  总检测框: {n_boxes} (原2773)')
print(f'  补充框数: {n_added_boxes}')
print(f'  涉及图像: {n_added_images} 张')
print(f'  其中原为空图被补充: {n_empty_filled} 张')
print('=' * 50)
