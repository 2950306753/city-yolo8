// AI生成
let sessionId = null;
const sessions = [];
const messages = document.querySelector('#messages');
const sessionList = document.querySelector('#session-list');
const conversationTitle = document.querySelector('#conversation-title');
const newSessionButton = document.querySelector('#new-session');
const status = document.querySelector('#status');
const statusDot = document.querySelector('#status-dot');
const configHint = document.querySelector('#config-hint');
const modelInfo = document.querySelector('#model-info');
const form = document.querySelector('#chat-form');
const input = document.querySelector('#message');
const send = document.querySelector('#send');
const sendLabel = document.querySelector('#send-label');
const sendLoading = document.querySelector('#send-loading');
const clear = document.querySelector('#clear');
const modelConfigButton = document.querySelector('#model-config-button');
const modelConfigDialog = document.querySelector('#model-config-dialog');
const modelConfigForm = document.querySelector('#model-config-form');
const modelConfigClose = document.querySelector('#model-config-close');
const modelConfigCancel = document.querySelector('#model-config-cancel');
const modelProvider = document.querySelector('#model-provider');
const modelBaseUrl = document.querySelector('#model-base-url');
const modelName = document.querySelector('#model-name');
const modelApiKey = document.querySelector('#model-api-key');
const modelKeyHint = document.querySelector('#model-key-hint');
const modelConfigError = document.querySelector('#model-config-error');
const modelConfigSave = document.querySelector('#model-config-save');
const detectZone = document.querySelector('#detect-zone');
const detectFile = document.querySelector('#detect-file');
const detectLoading = document.querySelector('#detect-loading');
const detectResult = document.querySelector('#detect-result');
let modelConfig = null;
const currentSession = () => sessions.find((s) => s.id === sessionId);

function createEmptyState() {
  const state = document.createElement('div');
  state.className = 'empty-state';
  state.innerHTML = '<div class="empty-icon" aria-hidden="true">✦</div><h2>上传图片开始检测</h2><p>或向 Agent 提问市容环卫相关问题。</p>';
  return state;
}

function createMessageElement(role, text) {
  const item = document.createElement('article');
  item.className = `message ${role}`;
  const label = document.createElement('span');
  label.className = 'message-label';
  label.textContent = role === 'user' ? '你' : role === 'agent' ? 'Agent' : '提示';
  const content = document.createElement('p');
  content.textContent = text;
  item.append(label, content);
  return item;
}

function renderMessages() {
  messages.replaceChildren();
  const session = currentSession();
  if (!session?.messages.length) { messages.append(createEmptyState()); return; }
  session.messages.forEach((m) => messages.append(createMessageElement(m.role, m.text)));
  messages.scrollTop = messages.scrollHeight;
}

function renderSessions() {
  sessionList.replaceChildren();
  sessions.forEach((session) => {
    const item = document.createElement('button');
    item.type = 'button';
    item.className = 'session-item';
    item.dataset.active = String(session.id === sessionId);
    item.textContent = session.title;
    item.addEventListener('click', () => { sessionId = session.id; conversationTitle.textContent = session.title; renderSessions(); renderMessages(); });
    sessionList.append(item);
  });
}

function createSession() {
  sessionId = crypto.randomUUID();
  sessions.unshift({ id: sessionId, title: '新会话', messages: [] });
  conversationTitle.textContent = '新会话';
  renderSessions();
  renderMessages();
  input.focus();
}

function addMessage(role, text) {
  const session = currentSession();
  if (!session) return;
  session.messages.push({ role, text });
  if (role === 'user' && session.title === '新会话') { session.title = text.slice(0, 22) || '新会话'; conversationTitle.textContent = session.title; renderSessions(); }
  renderMessages();
}

async function loadStatus() {
  try {
    const [healthResponse, configResponse] = await Promise.all([fetch('/health'), fetch('/config/status')]);
    const body = await configResponse.json();
    modelConfig = body;
    const healthy = healthResponse.ok && body.configured;
    status.textContent = healthy ? `${body.mode === 'mock' ? '模拟模式' : '在线模式'} · 服务正常` : '服务需要配置';
    statusDot.dataset.ok = healthy ? 'true' : 'false';
    configHint.textContent = body.mode === 'mock' ? '当前为模拟模式 · 配置模型可启用在线对话' : `${body.provider || '模型'} · ${body.model || '默认模型'}`;
  } catch {
    status.textContent = '服务不可用';
    statusDot.dataset.ok = 'false';
    configHint.textContent = '无法读取服务状态';
  }
  try {
    const r = await fetch('/api/model/status');
    const m = await r.json();
    if (m.loaded) { modelInfo.textContent = `检测模型: ${m.model_path} · ${m.classes.length} 类`; }
    else { modelInfo.textContent = '检测模型未加载'; }
  } catch { modelInfo.textContent = ''; }
}

function openModelConfig() {
  const current = modelConfig || {};
  modelProvider.value = current.provider || 'openai-compatible';
  modelBaseUrl.value = current.base_url || '';
  modelName.value = current.model || '';
  modelApiKey.value = '';
  modelApiKey.placeholder = current.has_api_key ? '已配置，留空表示不修改' : '首次配置时必填';
  modelKeyHint.textContent = current.has_api_key ? 'API Key 已配置。留空表示保留当前 Key。' : 'Key 仅保存到本地应用的 .env 文件，不会在页面中回显。';
  modelConfigError.hidden = true;
  modelConfigError.textContent = '';
  modelConfigDialog.showModal();
  modelName.focus();
}

function closeModelConfig() { modelConfigDialog.close(); modelApiKey.value = ''; }

async function saveModelConfig(event) {
  event.preventDefault();
  if (modelConfigSave.disabled) return;
  const payload = { provider: modelProvider.value.trim(), base_url: modelBaseUrl.value.trim(), model: modelName.value.trim() };
  if (modelApiKey.value.trim()) payload.api_key = modelApiKey.value.trim();
  modelConfigSave.disabled = true;
  modelConfigError.hidden = true;
  try {
    const response = await fetch('/api/config/model', { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
    const body = await response.json();
    if (!response.ok) throw new Error(body.message || '模型设置保存失败');
    modelConfig = body;
    closeModelConfig();
    await loadStatus();
  } catch (error) {
    modelConfigError.textContent = error instanceof Error ? error.message : '模型设置保存失败';
    modelConfigError.hidden = false;
  } finally { modelConfigSave.disabled = false; }
}

function renderDetectResult(result) {
  detectResult.replaceChildren();
  if (result.status !== 'ok') {
    const err = document.createElement('p');
    err.style.color = '#dc2626';
    err.textContent = result.message || '检测失败';
    detectResult.append(err);
    return;
  }
  const panel = document.createElement('div');
  panel.className = 'result-panel';
  if (result.annotated_image) {
    const imgWrap = document.createElement('div');
    imgWrap.className = 'result-image';
    const img = document.createElement('img');
    img.src = 'data:image/jpeg;base64,' + result.annotated_image;
    img.alt = '检测结果可视化';
    imgWrap.append(img);
    panel.append(imgWrap);
  }
  const tableWrap = document.createElement('div');
  tableWrap.className = 'result-table';
  const summary = document.createElement('div');
  summary.className = 'scene-summary';
  const scenes = Object.entries(result.scene_summary || {});
  summary.innerHTML = `<strong>检测到 ${result.num_objects} 个乱象</strong> ` + scenes.map(([k, v]) => `<span class="badge">${k}: ${v}</span>`).join('');
  tableWrap.append(summary);
  if (result.objects.length) {
    const table = document.createElement('table');
    table.innerHTML = '<thead><tr><th>类别</th><th>场景</th><th>置信度</th><th>位置(x,y,w,h)</th></tr></thead>';
    const tbody = document.createElement('tbody');
    result.objects.forEach((o) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>${o.category}</td><td>${o.scene}</td><td>${(o.score * 100).toFixed(1)}%</td><td>${o.bbox.map((v) => v.toFixed(0)).join(', ')}</td>`;
      tbody.append(tr);
    });
    table.append(tbody);
    tableWrap.append(table);
  } else {
    const none = document.createElement('p');
    none.textContent = '未检测到市容环卫乱象，场景正常。';
    tableWrap.append(none);
  }
  panel.append(tableWrap);
  detectResult.append(panel);
}

async function runDetect(file) {
  detectLoading.hidden = false;
  detectResult.replaceChildren();
  const data = new FormData();
  data.append('file', file);
  try {
    const response = await fetch('/api/detect', { method: 'POST', body: data });
    const body = await response.json();
    if (!response.ok) throw new Error(body.message || '检测失败');
    renderDetectResult(body);
    addMessage('agent', `已检测图片「${body.filename || file.name}」：发现 ${body.num_objects} 个乱象。`);
  } catch (error) {
    detectResult.replaceChildren();
    const err = document.createElement('p');
    err.style.color = '#dc2626';
    err.textContent = error instanceof Error ? error.message : '检测失败';
    detectResult.append(err);
  } finally { detectLoading.hidden = true; }
}

detectZone.addEventListener('click', () => detectFile.click());
detectFile.addEventListener('change', () => { if (detectFile.files[0]) runDetect(detectFile.files[0]); detectFile.value = ''; });
detectZone.addEventListener('dragover', (e) => { e.preventDefault(); detectZone.classList.add('dragging'); });
detectZone.addEventListener('dragleave', () => detectZone.classList.remove('dragging'));
detectZone.addEventListener('drop', (e) => { e.preventDefault(); detectZone.classList.remove('dragging'); if (e.dataTransfer.files[0]) runDetect(e.dataTransfer.files[0]); });

// 批量检测
const batchBtn = document.querySelector('#batch-btn');
const batchFile = document.querySelector('#batch-file');
const batchResult = document.querySelector('#batch-result');

async function runBatchDetect(files) {
  if (!files.length) return;
  detectLoading.hidden = false;
  batchResult.hidden = false;
  batchResult.replaceChildren();
  const data = new FormData();
  for (const f of files) data.append('files', f);
  try {
    const response = await fetch('/api/detect/batch', { method: 'POST', body: data });
    const body = await response.json();
    if (!response.ok) throw new Error(body.message || '批量检测失败');
    const summary = document.createElement('div');
    summary.style.cssText = 'padding:12px;background:#f0fdf4;border-radius:8px;margin-bottom:12px';
    const totalObj = body.results.reduce((s, r) => s + (r.num_objects || 0), 0);
    const withObj = body.results.filter((r) => r.num_objects > 0).length;
    summary.innerHTML = `<strong>批量检测完成</strong>：${body.count} 张图片，${withObj} 张检测到乱象，共 ${totalObj} 个检测框`;
    batchResult.append(summary);
    const table = document.createElement('table');
    table.style.cssText = 'width:100%;border-collapse:collapse;font-size:13px';
    table.innerHTML = '<thead><tr style="background:#f1f5f9"><th style="padding:6px">文件名</th><th style="padding:6px">检测数</th><th style="padding:6px">类别</th></tr></thead>';
    const tbody = document.createElement('tbody');
    body.results.forEach((r) => {
      const tr = document.createElement('tr');
      const cats = (r.objects || []).map((o) => o.category).join(', ') || '正常';
      tr.innerHTML = `<td style="padding:4px 6px;border-bottom:1px solid #e2e8f0">${r.filename || ''}</td><td style="padding:4px 6px;border-bottom:1px solid #e2e8f0">${r.num_objects || 0}</td><td style="padding:4px 6px;border-bottom:1px solid #e2e8f0">${cats}</td>`;
      tbody.append(tr);
    });
    table.append(tbody);
    batchResult.append(table);
    addMessage('agent', `批量检测 ${body.count} 张图片：${withObj} 张有乱象，共 ${totalObj} 个检测框。`);
  } catch (error) {
    batchResult.replaceChildren();
    const err = document.createElement('p');
    err.style.color = '#dc2626';
    err.textContent = error instanceof Error ? error.message : '批量检测失败';
    batchResult.append(err);
  } finally { detectLoading.hidden = true; }
}

batchBtn.addEventListener('click', () => batchFile.click());
batchFile.addEventListener('change', () => { if (batchFile.files.length) runBatchDetect([...batchFile.files]); batchFile.value = ''; });

// 检测统计
const statsBtn = document.querySelector('#stats-btn');

async function showStats() {
  try {
    const response = await fetch('/api/stats');
    const stats = await response.json();
    detectResult.replaceChildren();
    batchResult.hidden = true;
    const panel = document.createElement('div');
    panel.className = 'result-panel';
    const wrap = document.createElement('div');
    wrap.className = 'result-table';
    wrap.innerHTML = `<h3>检测统计</h3><p>总检测图片: ${stats.total_images} · 总检测框: ${stats.total_objects}</p>`;
    if (Object.keys(stats.by_class || {}).length) {
      const table = document.createElement('table');
      table.innerHTML = '<thead><tr><th>类别</th><th>数量</th></tr></thead>';
      const tbody = document.createElement('tbody');
      Object.entries(stats.by_class).sort((a, b) => b[1] - a[1]).forEach(([k, v]) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `<td>${k}</td><td>${v}</td>`;
        tbody.append(tr);
      });
      table.append(tbody);
      wrap.append(table);
    }
    const sceneWrap = document.createElement('div');
    sceneWrap.style.marginTop = '12px';
    sceneWrap.innerHTML = '<h4>场景分布</h4>' + Object.entries(stats.by_scene || {}).map(([k, v]) => `<span class="badge">${k}: ${v}</span>`).join('');
    wrap.append(sceneWrap);
    panel.append(wrap);
    detectResult.append(panel);
  } catch { addMessage('error', '无法获取统计信息'); }
}

statsBtn.addEventListener('click', showStats);

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const message = input.value.trim();
  if (!message || send.disabled) return;
  addMessage('user', message);
  input.value = '';
  send.disabled = true;
  sendLabel.hidden = true;
  sendLoading.hidden = false;
  try {
    const response = await fetch('/api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ message, session_id: sessionId }) });
    const body = await response.json();
    if (!response.ok) throw new Error(body.message || '请求失败');
    sessionId = body.session_id;
    addMessage('agent', body.answer);
  } catch (error) {
    addMessage('error', error instanceof Error ? error.message : '请求失败');
  } finally { send.disabled = false; sendLabel.hidden = false; sendLoading.hidden = true; input.focus(); }
});

input.addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); form.requestSubmit(); } });
modelConfigButton.addEventListener('click', openModelConfig);
modelConfigClose.addEventListener('click', closeModelConfig);
modelConfigCancel.addEventListener('click', closeModelConfig);
modelConfigForm.addEventListener('submit', saveModelConfig);
newSessionButton.addEventListener('click', createSession);
clear.addEventListener('click', () => { const session = currentSession(); if (session) { session.messages = []; session.title = '新会话'; conversationTitle.textContent = session.title; detectResult.replaceChildren(); renderSessions(); renderMessages(); } input.focus(); });
createSession();
loadStatus();
