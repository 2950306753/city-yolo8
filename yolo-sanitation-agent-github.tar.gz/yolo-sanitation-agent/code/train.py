# AI生成
"""微调 YOLOv8 检测模型（CPU 可用）。

以赛事基座 yolov8s.pt 为初始化权重，在 work/dataset 上微调 12 类市容环卫乱象。
最终权重固定输出到 work/runs/train/weights/best.pt。
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ROOT, WORK_DIR  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=os.path.join(ROOT, "yolov8s.pt"))
    ap.add_argument("--data", default=os.path.join(WORK_DIR, "dataset", "data.yaml"))
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--imgsz", type=int, default=416)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--fraction", type=float, default=1.0, help="使用训练集比例，用于快速验证")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--cache", action="store_true",
                    help="将图片缓存到内存(RAM)以加速训练；数据集约 3.7GB，内存充足时强烈建议开启")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--name", default="train")
    ap.add_argument("--patience", type=int, default=30)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    from ultralytics import YOLO

    project = os.path.join(WORK_DIR, "runs")
    if args.resume:
        ckpt = os.path.join(project, args.name, "weights", "last.pt")
        model = YOLO(ckpt)
        model.train(resume=True)
        return

    model = YOLO(args.model)
    model.train(
        data=args.data,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        fraction=args.fraction,
        workers=args.workers,
        device=args.device,
        project=project,
        name=args.name,
        patience=args.patience,
        exist_ok=True,
        pretrained=True,
        optimizer="AdamW",
        lr0=0.003,           # v4: 保守学习率，稳定收敛
        lrf=0.005,           # v4: 保守最终学习率
        cos_lr=True,         # 余弦退火
        label_smoothing=0.0, # v13: 轻微平滑，平衡P/R
        # 数据增强：更强增强提升泛化
        hsv_h=0.02,          # 色调增强
        hsv_s=0.7,           # 饱和度增强
        hsv_v=0.4,           # 明度增强
        degrees=10.0,        # v4: 旋转角度
        translate=0.2,       # 平移比例
        scale=0.5,           # v4: 缩放比例
        fliplr=0.5,          # 水平翻转概率
        mosaic=1.0,          # mosaic 增强
        mixup=0.25,          # v4: 较强mixup提升泛化
        copy_paste=0.2,     # v4: 较强copy_paste增强弱类
        weight_decay=0.001,  # v4: 标准权重衰减
        # 最后8个epoch关闭mosaic，提升最终收敛质量
        close_mosaic=8,      # v4: 较早关闭mosaic
        # 其他
        cache=args.cache,    # True=缓存到RAM，规避串行数据加载瓶颈
        amp=True,             # 混合精度训练，利用Tensor Core加速
        plots=True,
        val=True,
        seed=42,
    )
    print("[train] done ->", os.path.join(project, args.name, "weights", "best.pt"))


if __name__ == "__main__":
    main()
