# AI生成
#!/usr/bin/env bash
# AI生成
# 安装智能体 Web 服务依赖（Linux / macOS）
set -euo pipefail
cd "$(dirname "$0")"

echo "==> 安装基础依赖"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

echo "==> 安装 Web 服务依赖"
python -m pip install -r requirements-web.txt

echo "==> 完成。首次运行请复制 .env.example 为 .env 并填写模型 API Key。"