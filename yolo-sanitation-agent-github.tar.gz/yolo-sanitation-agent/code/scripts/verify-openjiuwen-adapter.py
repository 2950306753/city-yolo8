"""Verify the generated AgentCore adapter before enabling live mode."""

from __future__ import annotations

import argparse
import ast
import importlib
import importlib.metadata
import inspect
import json
import re
from pathlib import Path


def fail(errors: list[str], message: str) -> None:
    errors.append(message)


def imported_init_model_module(tree: ast.AST) -> str | None:
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            if any(alias.name == "init_model" for alias in node.names):
                return node.module
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agent", type=Path, default=Path("app/agent.py"))
    parser.add_argument("--runtime-state", type=Path, default=Path(".officeace-agent-runtime.json"))
    parser.add_argument("--source-only", action="store_true")
    args = parser.parse_args()

    source = args.agent.read_text(encoding="utf-8")
    tree = ast.parse(source, filename=str(args.agent))
    errors: list[str] = []
    profile = "openjiuwen-0.1.16"
    if args.runtime_state.exists():
        profile = json.loads(args.runtime_state.read_text(encoding="utf-8")).get("profile", profile)

    init_model_calls = [
        node for node in ast.walk(tree)
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == "init_model"
    ]
    if not init_model_calls:
        fail(errors, "could not find an init_model(...) call in app/agent.py")
    for call in init_model_calls:
        keywords = {keyword.arg: keyword.value for keyword in call.keywords if keyword.arg}
        for name in ("provider", "model_name", "api_key", "api_base"):
            if name not in keywords:
                fail(errors, f"init_model must use {name}=")
        for name in ("model", "base_url"):
            if name in keywords:
                fail(errors, f"init_model must not use {name}=")
        api_base = keywords.get("api_base")
        if isinstance(api_base, ast.Constant) and api_base.value is None:
            fail(errors, "api_base must be a non-empty string, not None")

    adapter_required = {
        r"ReActAgent\s*\(\s*AgentCard\s*\(": "adapter must construct ReActAgent(AgentCard(...))",
        r"\.set_llm\s*\(": "adapter must call agent.set_llm(model)",
        r"await\s+.*?\.invoke\s*\(": "adapter must await agent.invoke(...)",
    }
    for pattern, message in adapter_required.items():
        if not re.search(pattern, source, re.DOTALL):
            fail(errors, message)

    if profile == "officeace-openjiuwen-0.1.10":
        profile_forbidden = {
            r"llm_OpenAI": "llm_OpenAI is not a valid 0.1.10 provider value",
            r"\bReActAgentConfig\b": "0.1.10 must not use ReActAgentConfig",
            r"ReActAgent\s*\([^\)]*\bllm\s*=": "0.1.10 must not pass llm= to ReActAgent",
            r"\.configure\s*\(": "0.1.10 must not call agent.configure()",
            r"asyncio\.run\s*\(": "0.1.10 HTTP handlers must await invoke(), not call asyncio.run()",
            r"run_until_complete\s*\(": "0.1.10 HTTP handlers must await invoke(), not run an event loop directly",
            r"(?<!asyncio)\.run\s*\(": "0.1.10 must not use synchronous .run()",
        }
        for pattern, message in profile_forbidden.items():
            if re.search(pattern, source, re.DOTALL):
                fail(errors, message)
        if "openai-compatible" in source and not re.search(r"[\"']openai-compatible[\"']\s*:\s*[\"']OpenAI[\"']", source):
            fail(errors, "openai-compatible must explicitly map to the SDK provider OpenAI")
        if "deepseek" in source and not re.search(r"[\"']deepseek[\"']\s*:\s*[\"']DeepSeek[\"']", source):
            fail(errors, "deepseek must explicitly map to the SDK provider DeepSeek")

    if not args.source_only:
        try:
            actual_version = importlib.metadata.version("openjiuwen")
        except importlib.metadata.PackageNotFoundError:
            fail(errors, "openjiuwen is not installed in this interpreter")
        else:
            expected_version = "0.1.10" if profile == "officeace-openjiuwen-0.1.10" else "0.1.16"
            if actual_version != expected_version:
                fail(errors, f"runtime profile {profile} requires openjiuwen=={expected_version}, found {actual_version}")
            module_name = imported_init_model_module(tree)
            if not module_name:
                fail(errors, "could not find the init_model import in app/agent.py")
            else:
                try:
                    init_model = getattr(importlib.import_module(module_name), "init_model")
                    parameters = inspect.signature(init_model).parameters
                    missing = {"provider", "model_name", "api_key", "api_base"} - set(parameters)
                    if missing:
                        fail(errors, f"init_model signature is missing: {', '.join(sorted(missing))}")
                except Exception as exc:
                    fail(errors, f"could not inspect {module_name}.init_model: {type(exc).__name__}")

    if errors:
        print("OpenJiuwen adapter check failed:")
        for error in errors:
            print(f"- {error}")
        return 1
    print(f"OpenJiuwen adapter check passed for {profile}: {args.agent}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
