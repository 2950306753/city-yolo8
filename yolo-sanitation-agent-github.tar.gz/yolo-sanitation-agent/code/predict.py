# AI生成
"""对 test_set 全量图片推理，导出赛题格式的 result.json。

输出 schema 与 train_set/label/label.json 对齐：
    [{
        "filename": "...",
        "image_width": int,
        "image_height": int,
        "image_label": ["..."],
        "objects": [{"category": "...", "bbox": [x, y, w, h], "score": float}]
    }]

注意 bbox 约定为「左上角 + 宽高」即 [x_left, y_top, width, height]（赛题口径），
而非中心点 [cx, cy, w, h]。
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import CLASSES, OBJ_TO_IMAGE_LABEL, PER_CLASS_CONF, CLASS_TO_SCENE, ROOT, TEST_IMAGE_DIR, WORK_DIR  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=os.path.join(WORK_DIR, "runs", "train_opt", "weights", "best.pt"))
    ap.add_argument("--source", default=TEST_IMAGE_DIR)
    ap.add_argument("--out", default=os.path.join(ROOT, "result", "result.json"))
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--iou", type=float, default=0.45)
    ap.add_argument("--imgsz", type=int, default=416)
    ap.add_argument("--name", default="train_opt")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--augment", action="store_true", help="启用TTA测试时增强(多尺度+翻转)")
    args = ap.parse_args()

    from ultralytics import YOLO
    from PIL import Image

    if not os.path.isfile(args.model):
        raise FileNotFoundError(f"模型不存在: {args.model}")

    model = YOLO(args.model)
    names = model.names  # {id: name}

    files = sorted(
        f for f in os.listdir(args.source)
        if f.lower().endswith((".jpg", ".jpeg", ".png", ".bmp"))
    )
    # 优化策略：用全局低阈值获取所有候选框，再按分类别阈值后处理过滤
    global_conf = min(args.conf, 0.01)  # 全局低阈值，确保稀有类不漏检
    print(f"[predict] {len(files)} images, model={args.model}, global_conf={global_conf} (per-class filter ON)")

    results = model.predict(
        source=args.source,
        conf=global_conf,
        iou=args.iou,
        imgsz=args.imgsz,
        device=args.device,
        batch=args.batch,
        augment=args.augment,  # TTA: 多尺度+水平翻转
        verbose=False,
        save=False,
    )

    out = []
    by_name = {os.path.basename(r.path): r for r in results}
    for fn in files:
        path = os.path.join(args.source, fn)
        with Image.open(path) as im:
            w, h = im.size
        r = by_name.get(fn)
        objects = []
        if r is not None and r.boxes is not None and len(r.boxes) > 0:
            xyxy = r.boxes.xyxy.cpu().numpy()  # [x1, y1, x2, y2] 像素
            confs = r.boxes.conf.cpu().numpy()
            clss = r.boxes.cls.cpu().numpy().astype(int)
            for i in range(len(xyxy)):
                x1, y1, x2, y2 = xyxy[i]
                bw, bh = x2 - x1, y2 - y1
                cat = names.get(int(clss[i]), CLASSES[int(clss[i])] if 0 <= clss[i] < len(CLASSES) else "未知")
                score = float(confs[i])
                # 分类别置信度过滤：稀有类用更低阈值
                cls_threshold = PER_CLASS_CONF.get(cat, args.conf)
                if score < cls_threshold:
                    continue
                objects.append({
                    "category": cat,
                    "bbox": [round(float(x1), 1), round(float(y1), 1),
                             round(float(bw), 1), round(float(bh), 1)],
                    "score": round(score, 4),
                })
        # 图像级标签：由检测到的对象类别映射去重；无检测 -> 正常
        seen = []
        for o in objects:
            lab = OBJ_TO_IMAGE_LABEL.get(o["category"], o["category"])
            if lab not in seen:
                seen.append(lab)
        image_label = seen if seen else ["正常"]
        out.append({
            "filename": fn,
            "image_width": int(w),
            "image_height": int(h),
            "image_label": image_label,
            "objects": objects,
        })

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    n_obj = sum(len(e["objects"]) for e in out)
    n_pos = sum(1 for e in out if e["objects"])
    print(f"[predict] done -> {args.out}")
    print(f"[predict] images={len(out)} with_objects={n_pos} total_boxes={n_obj}")


if __name__ == "__main__":
    main()
