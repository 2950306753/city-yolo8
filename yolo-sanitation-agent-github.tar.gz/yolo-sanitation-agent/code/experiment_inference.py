# AI生成
"""推理策略对比实验：在验证集上对比多种推理配置的 mAP，选出最优推理策略。

对比维度：
    - 分辨率：416 / 512 / 640
    - TTA：关闭 / 开启（多尺度+水平翻转增强）
    - 置信度：0.001（获取全部候选框，交由分类别阈值后处理）

用法:
    python experiment_inference.py --model ../work/runs/train_v3/weights/best.pt
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ROOT, WORK_DIR  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=os.path.join(WORK_DIR, "runs", "train_v3", "weights", "best.pt"))
    ap.add_argument("--data", default=os.path.join(WORK_DIR, "dataset", "data.yaml"))
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--output", default=os.path.join(WORK_DIR, "inference_experiments.json"))
    args = ap.parse_args()

    from ultralytics import YOLO

    if not os.path.isfile(args.model):
        print(f"[exp] 模型不存在: {args.model}")
        sys.exit(1)

    model = YOLO(args.model)

    # 待对比的推理配置
    configs = [
        {"name": "baseline_416", "imgsz": 416, "augment": False},
        {"name": "tta_416", "imgsz": 416, "augment": True},
        {"name": "res_512", "imgsz": 512, "augment": False},
        {"name": "res_640", "imgsz": 640, "augment": False},
        {"name": "tta_512", "imgsz": 512, "augment": True},
    ]

    results = []
    print("\n" + "=" * 70)
    print(f"{'配置':<16} {'imgsz':>6} {'TTA':>5} {'mAP50':>8} {'mAP50-95':>9} {'精度':>8} {'召回':>8} {'耗时(s)':>9}")
    print("=" * 70)

    for cfg in configs:
        t0 = time.time()
        try:
            metrics = model.val(
                data=args.data,
                imgsz=cfg["imgsz"],
                augment=cfg["augment"],
                conf=0.001,
                iou=0.45,
                device=args.device,
                plots=False,
                verbose=False,
                save_json=False,
            )
            elapsed = time.time() - t0
            map50 = float(metrics.box.map50)
            map_all = float(metrics.box.map)
            precision = float(metrics.box.mp)
            recall = float(metrics.box.mr)
            results.append({
                "name": cfg["name"], "imgsz": cfg["imgsz"], "augment": cfg["augment"],
                "mAP50": round(map50, 4), "mAP50-95": round(map_all, 4),
                "precision": round(precision, 4), "recall": round(recall, 4),
                "elapsed_s": round(elapsed, 1),
            })
            print(f"{cfg['name']:<16} {cfg['imgsz']:>6} {str(cfg['augment']):>5} "
                  f"{map50:>8.4f} {map_all:>9.4f} {precision:>8.4f} {recall:>8.4f} {elapsed:>9.1f}")
        except Exception as exc:  # noqa: BLE001
            print(f"{cfg['name']:<16} 失败: {exc}")

    if not results:
        print("[exp] 无有效结果")
        sys.exit(1)

    best = max(results, key=lambda r: r["mAP50"])
    print("=" * 70)
    print(f"🏆 最优配置: {best['name']} (mAP50={best['mAP50']}, imgsz={best['imgsz']}, TTA={best['augment']})")

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump({"best": best, "all": results}, f, ensure_ascii=False, indent=2)
    print(f"[exp] 结果已保存到 {args.output}")


if __name__ == "__main__":
    main()
