"""YOLOv8l v3 快速训练：60轮 + 896分辨率 + 关闭mixup + 精简绘图开销"""
from ultralytics import YOLO

model = YOLO('/root/cloud_train_pack/yolov8l.pt')
results = model.train(
    data='/root/cloud_train_pack/work/dataset/data.yaml',
    epochs=60,
    imgsz=896,
    batch=16,
    lr0=0.001,
    lrf=0.01,
    optimizer='AdamW',
    cos_lr=True,
    weight_decay=0.0005,
    label_smoothing=0.05,
    dropout=0.1,
    patience=25,
    device=0,
    workers=16,
    cache='ram',
    amp=True,
    seed=42,
    name='train_yolov8l_v3',
    project='/root/cloud_train_pack/work/runs',
    exist_ok=True,
    hsv_h=0.02,
    hsv_s=0.7,
    hsv_v=0.4,
    degrees=10.0,
    translate=0.2,
    scale=0.5,
    fliplr=0.5,
    mosaic=1.0,
    mixup=0.0,
    copy_paste=0.3,
    close_mosaic=10,
    val=True,
    plots=False,
)
print('\n训练完成！')
print('最佳权重: /root/cloud_train_pack/work/runs/train_yolov8l_v3/weights/best.pt')
