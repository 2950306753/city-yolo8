# AI生成
# 安装智能体 Web 服务依赖（Windows PowerShell）
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

Write-Host "==> 安装基础依赖" -ForegroundColor Cyan
python -m pip install --upgrade pip
python -m pip install -r requirements.txt

Write-Host "==> 安装 Web 服务依赖" -ForegroundColor Cyan
python -m pip install -r requirements-web.txt

Write-Host "==> 完成。首次运行请复制 .env.example 为 .env 并填写模型 API Key。" -ForegroundColor Green