# AI生成
"""最优推理：多尺度 TTA + WBF 多尺度框融合 + 分类别阈值（最终交付口径）。

与 predict.py 的区别：
  predict.py           —— 单次推理（可选 augment），适合快速验证与阈值调优；
  inference_optimal.py —— 三尺度（640/768/896）TTA + WBF 融合，为最终提交口径。

用法：
  python inference_optimal.py --model models/best.pt --source ../test_set/image --out ../result/result.json
"""
import argparse
import json
import os
import sys

import numpy as np
from PIL import Image
from ultralytics import YOLO

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    CLASSES as CLASS_NAMES,
    OBJ_TO_IMAGE_LABEL,
    PER_CLASS_CONF,
    ROOT,
    TEST_IMAGE_DIR,
)

DEFAULT_MODEL = os.path.join(ROOT, "code", "models", "best.pt")
DEFAULT_OUT = os.path.join(ROOT, "result", "result.json")

# 多尺度配置与 WBF 融合权重（768 权重最高，实测最优）
DEFAULT_SCALES = [640, 768, 896]
SCALE_WEIGHTS = [0.4, 0.35, 0.25]
WBF_IOU_THR = 0.55


def wbf_fusion(all_preds_list, iou_thr=0.55, weights=None):
    """多尺度预测的 WBF 融合。

    all_preds_list: [scale][image] -> (boxes_xyxy, scores, labels)
    """
    if weights is None:
        weights = [1.0 / len(all_preds_list)] * len(all_preds_list)

    num_images = len(all_preds_list[0])
    fused_results = []

    for img_idx in range(num_images):
        all_boxes = []
        all_scores = []
        all_labels = []
        all_weights = []

        for scale_idx, preds in enumerate(all_preds_list):
            boxes, scores, labels = preds[img_idx]
            if len(boxes) == 0:
                continue
            w = weights[scale_idx]
            for box, score, label in zip(boxes, scores, labels):
                all_boxes.append(box)
                all_scores.append(score * w)
                all_labels.append(label)
                all_weights.append(w)

        if len(all_boxes) == 0:
            fused_results.append((np.array([]), np.array([]), np.array([])))
            continue

        all_boxes = np.array(all_boxes)
        all_scores = np.array(all_scores)
        all_labels = np.array(all_labels)
        all_weights = np.array(all_weights)

        order = np.argsort(-all_scores)
        all_boxes = all_boxes[order]
        all_scores = all_scores[order]
        all_labels = all_labels[order]
        all_weights = all_weights[order]

        fused_boxes = []
        fused_scores = []
        fused_labels = []
        used = set()

        for i in range(len(all_boxes)):
            if i in used:
                continue
            cluster = [i]
            for j in range(i + 1, len(all_boxes)):
                if j in used or all_labels[i] != all_labels[j]:
                    continue
                box_i, box_j = all_boxes[i], all_boxes[j]
                xi1, yi1 = max(box_i[0], box_j[0]), max(box_i[1], box_j[1])
                xi2, yi2 = min(box_i[2], box_j[2]), min(box_i[3], box_j[3])
                inter = max(0, xi2 - xi1) * max(0, yi2 - yi1)
                area_i = (box_i[2] - box_i[0]) * (box_i[3] - box_i[1])
                area_j = (box_j[2] - box_j[0]) * (box_j[3] - box_j[1])
                iou = inter / (area_i + area_j - inter + 1e-6)
                if iou >= iou_thr:
                    cluster.append(j)

            cluster_boxes = all_boxes[cluster]
            cluster_scores = all_scores[cluster]
            cluster_weights = all_weights[cluster]
            w_sum = cluster_weights.sum()
            fused_box = (cluster_boxes * cluster_weights[:, None]).sum(axis=0) / w_sum
            fused_score = cluster_scores.sum() / len(cluster)

            fused_boxes.append(fused_box)
            fused_scores.append(fused_score)
            fused_labels.append(all_labels[i])
            used.update(cluster)

        fused_results.append((
            np.array(fused_boxes),
            np.array(fused_scores),
            np.array(fused_labels).astype(int),
        ))

    return fused_results


def parse_args():
    ap = argparse.ArgumentParser(description="多尺度 TTA + WBF 融合最优推理")
    ap.add_argument("--model", default=DEFAULT_MODEL, help="YOLO 权重路径")
    ap.add_argument("--source", default=TEST_IMAGE_DIR, help="测试集图片目录")
    ap.add_argument("--out", default=DEFAULT_OUT, help="输出 result.json 路径")
    ap.add_argument("--device", default="cpu", help="推理设备，如 cpu / 0")
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--scales", default=",".join(str(s) for s in DEFAULT_SCALES),
                    help="逗号分隔的多尺度列表，默认 640,768,896")
    ap.add_argument("--wbf-iou", type=float, default=WBF_IOU_THR, help="WBF 聚类 IoU 阈值")
    return ap.parse_args()


def main():
    args = parse_args()
    scales = [int(s) for s in str(args.scales).split(",") if s.strip()]
    model = YOLO(args.model)
    files = sorted(
        f for f in os.listdir(args.source)
        if f.lower().endswith((".jpg", ".jpeg", ".png", ".bmp"))
    )
    print(f"测试集图像数: {len(files)}")

    # 多尺度 TTA 推理
    all_scale_preds = []
    for scale in scales:
        print(f"\n[尺度 {scale}] TTA推理中...")
        results = model.predict(
            source=args.source,
            conf=0.001,
            iou=0.65,
            imgsz=scale,
            device=args.device,
            batch=args.batch,
            augment=True,
            verbose=False,
            save=False,
        )

        by_name = {os.path.basename(r.path): r for r in results}
        preds = []
        for fn in files:
            r = by_name.get(fn)
            if r is not None and r.boxes is not None and len(r.boxes) > 0:
                boxes = r.boxes.xyxy.cpu().numpy()
                scores = r.boxes.conf.cpu().numpy()
                labels = r.boxes.cls.cpu().numpy().astype(int)
                preds.append((boxes, scores, labels))
            else:
                preds.append((np.array([]), np.array([]), np.array([])))
        all_scale_preds.append(preds)

        n_boxes = sum(len(p[0]) for p in preds)
        print(f"  检测框数: {n_boxes}")

    # WBF 融合
    print(f"\n[WBF] 融合 {len(scales)} 个尺度...")
    if len(scales) == len(SCALE_WEIGHTS):
        scale_weights = SCALE_WEIGHTS
    else:
        scale_weights = [1.0 / len(scales)] * len(scales)
    fused_preds = wbf_fusion(all_scale_preds, iou_thr=args.wbf_iou, weights=scale_weights)

    # 生成 result.json
    print("\n[输出] 生成 result.json...")
    out = []
    total_boxes = 0
    total_with_objects = 0

    for idx, fn in enumerate(files):
        path = os.path.join(args.source, fn)
        with Image.open(path) as im:
            w, h = im.size

        boxes, scores, labels = fused_preds[idx]
        objects = []

        for i in range(len(boxes)):
            x1, y1, x2, y2 = boxes[i]
            score = float(scores[i])
            cls_id = int(labels[i])
            cat = CLASS_NAMES[cls_id] if 0 <= cls_id < len(CLASS_NAMES) else "未知"

            # 分类别阈值过滤（稀有类用低阈值防漏检）
            cls_threshold = PER_CLASS_CONF.get(cat, 0.25)
            if score < cls_threshold:
                continue

            bw = x2 - x1
            bh = y2 - y1
            objects.append({
                "category": cat,
                # 左上角约定 [x_left, y_top, width, height]
                "bbox": [round(float(x1), 1), round(float(y1), 1),
                         round(float(bw), 1), round(float(bh), 1)],
                "score": round(score, 4),
            })

        seen = []
        for o in objects:
            lab = OBJ_TO_IMAGE_LABEL.get(o["category"], o["category"])
            if lab not in seen:
                seen.append(lab)
        image_label = seen if seen else ["正常"]

        out.append({
            "filename": fn,
            "image_width": int(w),
            "image_height": int(h),
            "image_label": image_label,
            "objects": objects,
        })

        if objects:
            total_with_objects += 1
        total_boxes += len(objects)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"\n{'=' * 50}")
    print("推理完成！")
    print(f"  输出文件: {args.out}")
    print(f"  图像总数: {len(files)}")
    print(f"  有目标图像: {total_with_objects}")
    print(f"  总检测框数: {total_boxes}")
    print(f"{'=' * 50}")


if __name__ == '__main__':
    main()