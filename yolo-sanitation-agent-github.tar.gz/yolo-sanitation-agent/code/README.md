# code —— 源码说明

本目录是「市容环卫综合乱象检测」的全部实现：检测模型训练 / 推理 + 智能体服务。

## 一、核心模块

| 文件 | 作用 |
| --- | --- |
| `common.py` | **唯一权威定义**：12 类别表、`CLASS_TO_ID`、图像级标签映射（`OBJ_TO_IMAGE_LABEL`）、分类别阈值（`PER_CLASS_CONF`）、场景分组（`SCENE_GROUPS`）、数据路径、`normalize_bbox` |
| `train.py` | YOLOv8m 单阶段微调入口（imgsz 768 / 40 ep / AdamW / cos_lr） |
| `train_yolov8l_v3.py` | YOLOv8l 对照实验配置 |
| `predict.py` | 单次推理（可选 `--augment`），用于快速验证与阈值调优 |
| `inference_optimal.py` | **最终交付口径**：三尺度（640/768/896）TTA + WBF 框融合 + 分类别阈值 |
| `merge_hybrid.py` | 双模型 WBF 融合（对照实验，非最终方案） |
| `tune_thresholds.py` | 分类别置信度阈值自动搜索（验证集 F1 贪心一对一匹配，IoU≥0.5） |
| `experiment_inference.py` | 推理参数对比实验（分辨率 / augment / TTA） |
| `dataset_build.py` | 数据集构建与校验 |
| `oversample.py` | 长尾类别过采样（无序 ×8 / 破损 ×8 / 地面不洁 ×3 / 冒装 ×3） |
| `post_train_pipeline.py` | 训练后处理流水线（阈值搜索 → 推理 → 结果汇总） |

## 二、智能体服务（`app/` + `web/`）

| 文件 | 作用 |
| --- | --- |
| `app/api.py` | FastAPI 应用：`/health` `/ready` `/config/status` `/api/model/status` `/api/stats` `/api/chat` `/api/detect` `/api/detect/batch`，并挂载 `web/` 静态资源 |
| `app/detector.py` | YOLO 推理单例封装，输出结构化 `objects`（`category` / `bbox` / `score` / `scene`） |
| `app/agent.py` | OpenJiuwen AgentCore 适配层（`init_model` + `ReActAgent`），含 `MockAgent` / `UnavailableAgent` 降级 |
| `app/config.py` | 运行配置（`.env` → `Settings`），支持在线切换模型并原子写回 |
| `web/` | 原生 HTML/CSS/JS 前端，上传图片 → 对话式检测 |
| `scripts/verify-openjiuwen-adapter.py` | 适配层静态校验（AST + 正则），确保与 openjiuwen 0.1.16 接口一致 |

## 三、快速命令

```bash
# 训练（需先放置 train_set/）
python train.py

# 生成最终提交结果
python inference_optimal.py --model models/best.pt --source ../test_set/image --out ../result/result.json

# 启动智能体服务
python start.py                 # 或 .\start.ps1 / bash start.sh
```

## 四、环境变量

复制 `.env.example` 为 `.env`：

| 键 | 说明 |
| --- | --- |
| `AGENT_MODE` | `mock`（模板回复） / `live`（真实大模型） |
| `AGENT_MODEL_PROVIDER` | `openai-compatible` / `openai` / `deepseek` |
| `AGENT_MODEL_NAME` | 模型名称，如 `deepseek-chat` |
| `AGENT_MODEL_API_KEY` | 模型 API Key（**不入库**） |
| `AGENT_MODEL_BASE_URL` | OpenAI 兼容接口基址 |
| `HOST` / `PORT` | 服务监听地址，默认 `127.0.0.1:8000` |

## 五、数据放置约定

`common.py` 以 `ROOT = 上一级目录` 为基准：

```
<ROOT>/train_set/image/*.jpg
<ROOT>/train_set/label/label.json
<ROOT>/test_set/image/*.jpg
<ROOT>/code/models/best.pt          # 权重
<ROOT>/result/result.json           # 输出
```

## 六、输出格式

`bbox` 为左上角像素约定 `[x_left, y_top, width, height]`；`image_label` 由对象级类别经 `OBJ_TO_IMAGE_LABEL` 映射去重，无目标时输出 `["正常"]`。