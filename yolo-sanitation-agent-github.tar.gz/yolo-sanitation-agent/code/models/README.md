# models —— 权重放置目录

本目录用于存放推理所需的 YOLO 权重，**文件本身不入版本库**（`.gitignore` 已忽略 `*.pt`）。

## 需要放入的文件

| 文件名 | 说明 |
| --- | --- |
| `best.pt` | 赛题微调后的 YOLOv8m 权重（约 50 MB），`inference_optimal.py` / `app/detector.py` 的默认查找路径 |

## 获取方式（二选一）

1. **自行训练**：按仓库根 `README.md` §3 准备环境与数据，运行
   ```bash
   cd code
   python train.py
   ```
   训练完成后从 `runs/train/weights/best.pt` 复制到本目录并改名 `best.pt`。

2. **下载发布权重**：从仓库 Releases 附件下载赛题微调权重压缩包，解压后放置为本目录下的 `best.pt`。

## 校验

```bash
python -c "from ultralytics import YOLO; m=YOLO('models/best.pt'); print(m.names)"
```

输出应包含 12 个类别，且顺序与 `code/common.py` 中 `CLASSES` 完全一致：

```
0 游摊 / 1 门店超范围 / 2 垃圾桶沿街摆放 / 3 垃圾桶脏污 / 4 垃圾混投 / 5 垃圾桶不规范
6 垃圾乱堆 / 7 垃圾冒装 / 8 地面不洁 / 9 垃圾桶无分类标识 / 10 垃圾桶破损 / 11 垃圾桶无序
```

> 若类别顺序不一致，检测结果会被错误映射到图像级标签，必须重新导出权重。

## 说明

- Ultralytics 预训练基座（`yolov8s.pt` / `yolov8m.pt`）为只读基座，训练时由 `train.py` 自动下载，**无需**放入本目录。
- 推理时 `detector.py` 的候选权重查找顺序：`code/models/best.pt` → `work/runs/train_opt/weights/best.pt` → `work/runs/train/weights/best.pt` → `yolov8s.pt`。