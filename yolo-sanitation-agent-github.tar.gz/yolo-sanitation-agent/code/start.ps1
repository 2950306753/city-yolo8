# AI生成
# 启动市容环卫智能体 Web 服务（Windows PowerShell）
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

Write-Host "==> 启动智能体 Web 服务" -ForegroundColor Cyan
python start.py @args