# AI生成
"""跨平台启动器：启动市容环卫智能体 Web 服务。

用法：
    python start.py                # 读取 .env / 环境变量，默认 127.0.0.1:8000
    python start.py --host 0.0.0.0 --port 9000
"""
from __future__ import annotations

import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def load_dotenv(path: str) -> None:
    """极简 .env 解析：仅支持 KEY=VALUE，不覆盖已存在的环境变量。"""
    if not os.path.isfile(path):
        return
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value


def main() -> int:
    load_dotenv(os.path.join(HERE, ".env"))

    ap = argparse.ArgumentParser(description="启动智能体 Web 服务")
    ap.add_argument("--host", default=os.environ.get("HOST", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", "8000")))
    ap.add_argument("--reload", action="store_true", help="开发模式自动重载")
    args = ap.parse_args()

    try:
        import uvicorn
    except ImportError:
        print("缺少依赖：uvicorn。请先执行 pip install -r requirements-web.txt", file=sys.stderr)
        return 1

    print(f"服务启动中： http://{args.host}:{args.port}")
    uvicorn.run("app.api:app", host=args.host, port=args.port, reload=args.reload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())