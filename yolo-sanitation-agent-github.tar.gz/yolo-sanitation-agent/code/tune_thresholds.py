# AI生成
"""基于验证集自动调优分类别置信度阈值。

对每个类别在验证集上扫描不同置信度阈值，计算 F1 分数，
选取 F1 最高的阈值作为该类别的最佳阈值。
最终输出更新后的 PER_CLASS_CONF 字典，可直接粘贴到 common.py。
"""
from __future__ import annotations

import json
import os
import sys
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import CLASSES, ROOT, WORK_DIR  # noqa: E402


def resolve_val_dirs(args):
    """确定验证集图片/标签目录：优先命令行参数，其次由 data.yaml 推导，最后回退默认。"""
    if args.val_img_dir:
        img_dir = args.val_img_dir
        lbl_dir = args.val_lbl_dir or os.path.join(
            os.path.dirname(img_dir), "labels", os.path.basename(img_dir))
        return img_dir, lbl_dir
    try:
        import yaml  # ultralytics 依赖 pyyaml
        with open(args.data, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f)
        base = cfg.get("path") or os.path.dirname(os.path.abspath(args.data))
        val = cfg.get("val", "images/val")
        if isinstance(val, (list, tuple)):
            val = val[0]
        val = str(val)
        img_dir = val if os.path.isabs(val) else os.path.join(base, val)
        # 标签目录：将路径中的 images 段替换为 labels
        marker_img = os.sep + "images" + os.sep
        marker_lbl = os.sep + "labels" + os.sep
        if marker_img in img_dir:
            lbl_dir = img_dir.replace(marker_img, marker_lbl)
        else:
            lbl_dir = os.path.join(os.path.dirname(img_dir), "labels")
        return img_dir, lbl_dir
    except Exception:  # noqa: BLE001
        pass
    return (os.path.join(WORK_DIR, "dataset", "images", "val"),
            os.path.join(WORK_DIR, "dataset", "labels", "val"))


def _iou(a, b):
    """两个归一化 xyxy 框的 IoU。"""
    ix1, iy1 = max(a[0], b[0]), max(a[1], b[1])
    ix2, iy2 = min(a[2], b[2]), min(a[3], b[3])
    iw, ih = max(0.0, ix2 - ix1), max(0.0, iy2 - iy1)
    inter = iw * ih
    ua = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter
    return inter / ua if ua > 0 else 0.0


def main():
    ap = __import__("argparse").ArgumentParser()
    ap.add_argument("--model", default=os.path.join(WORK_DIR, "runs", "train_v3", "weights", "best.pt"))
    ap.add_argument("--data", default=os.path.join(WORK_DIR, "dataset", "data.yaml"))
    ap.add_argument("--imgsz", type=int, default=416)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--output", default=os.path.join(WORK_DIR, "tuned_thresholds.json"))
    ap.add_argument("--val-img-dir", default=None, help="验证集图片目录；不传则按 --data 自动推导")
    ap.add_argument("--val-lbl-dir", default=None, help="验证集标签目录；不传则按 --data 自动推导")
    args = ap.parse_args()

    from ultralytics import YOLO

    if not os.path.isfile(args.model):
        print(f"[tune] 模型不存在: {args.model}")
        return

    model = YOLO(args.model)
    names = model.names  # {id: name}

    # 1. 在验证集上用极低阈值推理，获取所有候选框
    print("[tune] 在验证集上推理（conf=0.001 获取所有候选框）...")
    results = model.val(
        data=args.data,
        conf=0.001,
        iou=0.45,
        imgsz=args.imgsz,
        device=args.device,
        plots=False,
        verbose=False,
        save=False,
        save_json=False,
    )

    # 2. 从验证结果中提取每个类别的 PR 曲线数据
    # ultralytics 的 val 返回 metrics 对象
    print(f"[tune] mAP50={results.box.map50:.4f}, mAP50-95={results.box.map:.4f}")

    # 3. 对每个类别，扫描阈值并计算 F1
    # 我们直接用 model.predict 在 val 集上推理，然后与 GT 对比
    val_img_dir, val_lbl_dir = resolve_val_dirs(args)

    if not os.path.isdir(val_img_dir):
        print(f"[tune] 验证集目录不存在: {val_img_dir}")
        return

    # 加载 GT（类别 + 归一化 xyxy 框），用于正确的 IoU 匹配
    gt_by_file: dict[str, list[tuple[int, list[float]]]] = {}
    for lbl_file in os.listdir(val_lbl_dir):
        if not lbl_file.endswith(".txt"):
            continue
        stem = os.path.splitext(lbl_file)[0]
        boxes: list[tuple[int, list[float]]] = []
        with open(os.path.join(val_lbl_dir, lbl_file), "r") as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 5:
                    c = int(float(parts[0]))
                    cx, cy, bw, bh = (float(parts[1]), float(parts[2]),
                                      float(parts[3]), float(parts[4]))
                    x1, y1 = cx - bw / 2, cy - bh / 2
                    x2, y2 = cx + bw / 2, cy + bh / 2
                    boxes.append((c, [x1, y1, x2, y2]))
        gt_by_file[stem] = boxes

    # 推理
    print("[tune] 推理验证集...")
    preds = model.predict(
        source=val_img_dir,
        conf=0.001,
        iou=0.45,
        imgsz=args.imgsz,
        device=args.device,
        verbose=False,
        save=False,
    )

    # 收集每个类别的 (confidence, is_tp) 列表
    # is_tp: 该检测框是否通过 IoU>=0.5 贪心一对一匹配到同类 GT（标准评测口径）
    cls_preds: dict[int, list[tuple[float, bool]]] = defaultdict(list)
    cls_gt_count: dict[int, int] = defaultdict(int)

    for boxes in gt_by_file.values():
        for c, _ in boxes:
            cls_gt_count[c] += 1

    for r in preds:
        stem = os.path.splitext(os.path.basename(r.path))[0]
        gt_boxes = gt_by_file.get(stem, [])
        h, w = r.orig_shape[:2]
        gt_by_cls: dict[int, list[list[float]]] = defaultdict(list)
        for c, bx in gt_boxes:
            gt_by_cls[c].append(bx)
        matched = {c: [False] * len(v) for c, v in gt_by_cls.items()}

        if r.boxes is not None and len(r.boxes) > 0:
            confs = r.boxes.conf.cpu().numpy()
            clss = r.boxes.cls.cpu().numpy().astype(int)
            xyxy = r.boxes.xyxy.cpu().numpy()
            order = confs.argsort()[::-1]  # 高置信度优先匹配
            for idx in order:
                cls_id = int(clss[idx])
                conf = float(confs[idx])
                bx = [float(xyxy[idx][0]) / w, float(xyxy[idx][1]) / h,
                      float(xyxy[idx][2]) / w, float(xyxy[idx][3]) / h]
                best_j, best_iou = -1, 0.0
                for j, g in enumerate(gt_by_cls.get(cls_id, [])):
                    if matched[cls_id][j]:
                        continue
                    iv = _iou(bx, g)
                    if iv > best_iou:
                        best_iou, best_j = iv, j
                is_tp = best_iou >= 0.5
                if is_tp:
                    matched[cls_id][best_j] = True
                cls_preds[cls_id].append((conf, is_tp))

    # 4. 对每个类别扫描阈值，找最佳 F1
    thresholds_to_try = [0.01, 0.02, 0.03, 0.05, 0.08, 0.10, 0.12, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.50]
    best_thresholds = {}

    print("\n[tune] 分类别最佳阈值（按 F1 优化）：")
    print(f"{'类别':<20} {'GT数':>6} {'候选框':>8} {'最佳阈值':>8} {'最佳F1':>8} {'TP':>6} {'FP':>6}")
    print("-" * 80)

    for cls_id in range(len(CLASSES)):
        cls_name = CLASSES[cls_id]
        preds_list = cls_preds.get(cls_id, [])
        gt_count = cls_gt_count.get(cls_id, 0)

        if not preds_list or gt_count == 0:
            best_thresholds[cls_name] = 0.05  # 默认低阈值
            print(f"{cls_name:<20} {gt_count:>6} {len(preds_list):>8} {'N/A':>8} {'N/A':>8} {'-':>6} {'-':>6}")
            continue

        best_f1 = 0
        best_thr = 0.05
        best_tp = 0
        best_fp = 0

        for thr in thresholds_to_try:
            tp = sum(1 for conf, correct in preds_list if conf >= thr and correct)
            fp = sum(1 for conf, correct in preds_list if conf >= thr and not correct)
            fn = gt_count - tp
            precision = tp / (tp + fp) if (tp + fp) > 0 else 0
            recall = tp / (tp + fn) if (tp + fn) > 0 else 0
            f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
            if f1 > best_f1:
                best_f1 = f1
                best_thr = thr
                best_tp = tp
                best_fp = fp

        best_thresholds[cls_name] = best_thr
        print(f"{cls_name:<20} {gt_count:>6} {len(preds_list):>8} {best_thr:>8.2f} {best_f1:>8.4f} {best_tp:>6} {best_fp:>6}")

    # 5. 输出可粘贴的 PER_CLASS_CONF
    print("\n[tune] 更新后的 PER_CLASS_CONF（粘贴到 common.py）：")
    print("PER_CLASS_CONF = {")
    for cls_name in CLASSES:
        print(f'    "{cls_name}": {best_thresholds[cls_name]:.2f},')
    print("}")

    # 6. 保存到文件
    out_path = args.output
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(best_thresholds, f, ensure_ascii=False, indent=2)
    print(f"\n[tune] 已保存到 {out_path}")


if __name__ == "__main__":
    main()
