# AI生成
"""对 YOLO 数据集中稀有类别进行分层过采样，缓解长尾分布。

V3 优化：按稀有程度分层过采样
  - 实例数 < 20  → 8 倍（极稀有：垃圾桶无序、垃圾桶破损、地面不洁）
  - 实例数 < 50  → 5 倍（较稀有：垃圾冒装、垃圾桶无分类标识）
  - 实例数 < 100 → 3 倍（一般稀有：垃圾桶脏污、垃圾混投、垃圾桶不规范、垃圾乱堆）
  - 实例数 ≥ 100 → 不过采样
"""
from __future__ import annotations

import os
import sys
import shutil
import random
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import ROOT, WORK_DIR  # noqa: E402

DATASET_DIR = os.path.join(WORK_DIR, "dataset")
TRAIN_IMG = os.path.join(DATASET_DIR, "images", "train")
TRAIN_LBL = os.path.join(DATASET_DIR, "labels", "train")


def get_oversample_factor(count: int) -> int:
    """根据类别实例数返回过采样倍数（分层策略）。"""
    if count < 5:
        return 12
    elif count < 10:
        return 10
    elif count < 20:
        return 8
    elif count < 50:
        return 5
    elif count < 100:
        return 3
    else:
        return 0  # 不需要过采样


def clean_oversampled():
    """清理之前的过采样文件（_os 后缀）。"""
    removed = 0
    for d in (TRAIN_IMG, TRAIN_LBL):
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if "_os" in f:
                os.remove(os.path.join(d, f))
                removed += 1
    print(f"[oversample] 清理旧过采样文件: {removed} 个")


def main():
    clean_oversampled()

    # 1. 统计每个类别的实例数
    class_counts = Counter()
    img_to_classes: dict[str, set[int]] = {}

    for lbl_file in os.listdir(TRAIN_LBL):
        if not lbl_file.endswith(".txt"):
            continue
        stem = os.path.splitext(lbl_file)[0]
        path = os.path.join(TRAIN_LBL, lbl_file)
        classes_in_img: set[int] = set()
        with open(path, "r") as f:
            for line in f:
                parts = line.strip().split()
                if parts:
                    cls_id = int(parts[0])
                    class_counts[cls_id] += 1
                    classes_in_img.add(cls_id)
        img_to_classes[stem] = classes_in_img

    print(f"[oversample] 原始图片数: {len(img_to_classes)}")
    print(f"[oversample] 类别分布: {dict(sorted(class_counts.items()))}")

    # 2. 计算每个类别的过采样倍数
    cls_factors = {}
    for cls_id, cnt in class_counts.items():
        factor = get_oversample_factor(cnt)
        if factor > 0:
            cls_factors[cls_id] = factor
    print(f"[oversample] 过采样倍数: {dict(sorted(cls_factors.items()))}")

    if not cls_factors:
        print("[oversample] 无类别需要过采样")
        return

    # 3. 对每张图片，按其包含的最稀有类别决定过采样倍数
    #    图片的过采样倍数 = max(该图片中所有类别的倍数)
    img_factors = {}
    for stem, classes in img_to_classes.items():
        max_factor = 0
        for cls_id in classes:
            if cls_id in cls_factors:
                max_factor = max(max_factor, cls_factors[cls_id])
        if max_factor > 0:
            img_factors[stem] = max_factor

    print(f"[oversample] 需过采样图片: {len(img_factors)} 张")

    # 4. 过采样：复制图片和标签
    created = 0
    for stem, factor in img_factors.items():
        img_src = None
        img_ext = None
        for ext in (".jpg", ".jpeg", ".png", ".bmp"):
            candidate = os.path.join(TRAIN_IMG, stem + ext)
            if os.path.exists(candidate):
                img_src = candidate
                img_ext = ext
                break
        if not img_src:
            continue

        lbl_src = os.path.join(TRAIN_LBL, stem + ".txt")

        base_boxes = []
        if os.path.exists(lbl_src):
            with open(lbl_src, "r") as f:
                for line in f:
                    p = line.strip().split()
                    if len(p) >= 5:
                        base_boxes.append((int(float(p[0])), float(p[1]),
                                           float(p[2]), float(p[3]), float(p[4])))

        from PIL import Image, ImageEnhance
        for i in range(1, factor + 1):
            new_stem = f"{stem}_os{i}"
            new_img = os.path.join(TRAIN_IMG, new_stem + ".jpg")
            new_lbl = os.path.join(TRAIN_LBL, new_stem + ".txt")
            if os.path.exists(new_img):
                continue
            rng = random.Random(f"{stem}_{i}")
            with Image.open(img_src) as im:
                aug = im.convert("RGB")
                aug = ImageEnhance.Brightness(aug).enhance(rng.uniform(0.88, 1.12))
                aug = ImageEnhance.Contrast(aug).enhance(rng.uniform(0.90, 1.10))
                aug = ImageEnhance.Color(aug).enhance(rng.uniform(0.90, 1.10))
                new_boxes = list(base_boxes)
                if rng.random() < 0.5:
                    aug = aug.transpose(Image.FLIP_LEFT_RIGHT)
                    new_boxes = [(c, 1.0 - cx, cy, w, h) for c, cx, cy, w, h in new_boxes]
            aug.save(new_img, quality=92)
            with open(new_lbl, "w") as f:
                for c, cx, cy, w, h in new_boxes:
                    f.write(f"{c} {cx:.6f} {cy:.6f} {w:.6f} {h:.6f}\n")
            created += 1

    print(f"[oversample] 过采样创建 {created} 张副本")

    # 5. 重新统计
    new_count = len([f for f in os.listdir(TRAIN_LBL) if f.endswith(".txt")])
    new_class_counts = Counter()
    for lbl_file in os.listdir(TRAIN_LBL):
        if not lbl_file.endswith(".txt"):
            continue
        with open(os.path.join(TRAIN_LBL, lbl_file), "r") as f:
            for line in f:
                parts = line.strip().split()
                if parts:
                    new_class_counts[int(parts[0])] += 1

    print(f"[oversample] 过采样后图片数: {new_count}")
    print(f"[oversample] 过采样后类别分布: {dict(sorted(new_class_counts.items()))}")


if __name__ == "__main__":
    main()
