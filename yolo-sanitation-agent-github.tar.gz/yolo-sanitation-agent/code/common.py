# AI生成
"""市容环卫综合乱象检测 - 公共定义。

统一维护类别表、图像级标签映射与数据路径，确保训练、推理、评测三处口径一致。
"""
from __future__ import annotations

import os

# 目标检测类别（对象级），顺序即为 YOLO 的 class_id。
CLASSES = [
    "游摊",
    "门店超范围",
    "垃圾桶沿街摆放",
    "垃圾桶脏污",
    "垃圾混投",
    "垃圾桶不规范",
    "垃圾乱堆",
    "垃圾冒装",
    "地面不洁",
    "垃圾桶无分类标识",
    "垃圾桶破损",
    "垃圾桶无序",
]

CLASS_TO_ID = {c: i for i, c in enumerate(CLASSES)}

# 对象级类别 -> 图像级标签（与赛题 image_label 口径对齐）
OBJ_TO_IMAGE_LABEL = {
    "游摊": "游摊占道",
    "门店超范围": "门店超范围经营",
    "垃圾桶沿街摆放": "垃圾桶沿街摆放",
    "垃圾桶脏污": "垃圾桶脏污",
    "垃圾混投": "垃圾混投",
    "垃圾桶不规范": "垃圾桶不规范",
    "垃圾乱堆": "垃圾乱堆",
    "垃圾冒装": "垃圾冒装",
    "地面不洁": "地面不洁",
    "垃圾桶无分类标识": "垃圾桶无分类标识",
    "垃圾桶破损": "垃圾桶破损",
    "垃圾桶无序": "垃圾桶无序",
}

# 图像级标签全集（含非目标类）
IMAGE_LABELS = sorted(set(OBJ_TO_IMAGE_LABEL.values()) | {"正常", "图像损坏"})

# 分类别置信度阈值（最终最优配置）
# 调优依据：验证集上按类别做 F1 最优搜索（贪心一对一匹配，IoU>=0.5），
#          配合 v9_40 三尺度 TTA（640/768/896）+ WBF 融合。
# 策略：稀有类用低阈值防漏检，易误报类用高阈值防误报。
# 推理时先用全局低阈值 (conf=0.01) 获取所有候选框，再按此表做后处理过滤。
PER_CLASS_CONF = {
    "游摊": 0.25,
    "门店超范围": 0.35,
    "垃圾桶沿街摆放": 0.12,
    "垃圾桶脏污": 0.15,
    "垃圾混投": 0.20,
    "垃圾桶不规范": 0.10,
    "垃圾乱堆": 0.08,
    "垃圾冒装": 0.02,
    "地面不洁": 0.01,
    "垃圾桶无分类标识": 0.30,
    "垃圾桶破损": 0.01,
    "垃圾桶无序": 0.01,
}

# 场景分组：12 类 -> 3 大场景
SCENE_GROUPS = {
    "垃圾分类设施": ["垃圾桶沿街摆放", "垃圾桶脏污", "垃圾桶不规范", "垃圾桶无分类标识", "垃圾桶破损", "垃圾桶无序", "垃圾混投", "垃圾冒装"],
    "道路环境卫生": ["地面不洁", "垃圾乱堆"],
    "占道经营": ["游摊", "门店超范围"],
}

# 类别 -> 场景 反查表
CLASS_TO_SCENE = {}
for _scene, _classes in SCENE_GROUPS.items():
    for _cls in _classes:
        CLASS_TO_SCENE[_cls] = _scene

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TRAIN_IMAGE_DIR = os.path.join(ROOT, "train_set", "image")
TRAIN_LABEL = os.path.join(ROOT, "train_set", "label", "label.json")
TEST_IMAGE_DIR = os.path.join(ROOT, "test_set", "image")
WORK_DIR = os.path.join(ROOT, "work")
OUTPUT_DIR = os.path.join(ROOT, "output")


def normalize_bbox(bbox, w, h):
    """像素 [x, y, w, h] -> 归一化 [cx, cy, w, h]，并裁剪到 [0, 1]。"""
    x, y, bw, bh = bbox
    cx = (x + bw / 2.0) / w
    cy = (y + bh / 2.0) / h
    nw = bw / w
    nh = bh / h
    cx = min(max(cx, 0.0), 1.0)
    cy = min(max(cy, 0.0), 1.0)
    nw = min(max(nw, 0.0), 1.0)
    nh = min(max(nh, 0.0), 1.0)
    return cx, cy, nw, nh
