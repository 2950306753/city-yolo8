# AI生成
from __future__ import annotations

from threading import RLock
from typing import Protocol

from openjiuwen.core.foundation.llm import init_model
from openjiuwen.core.single_agent.agents.react_agent import ReActAgent
from openjiuwen.core.single_agent.schema.agent_card import AgentCard

from .config import settings


class AgentUnavailableError(RuntimeError):
    pass


class AgentAdapter(Protocol):
    async def answer(self, message: str, session_id: str, file_ids: list[str] | None = None) -> str: ...


class MockAgent:
    async def answer(self, message: str, session_id: str, file_ids: list[str] | None = None) -> str:
        attachment_note = f" Attached files: {len(file_ids or [])}." if file_ids else ""
        return f"Mock response for session {session_id}: {message}{attachment_note}"


class UnavailableAgent:
    async def answer(self, message: str, session_id: str, file_ids: list[str] | None = None) -> str:
        raise AgentUnavailableError("Model configuration is incomplete")


PROVIDER_MAP = {
    "openai-compatible": "OpenAI",
    "openai": "OpenAI",
    "deepseek": "DeepSeek",
}


class OpenJiuwenLiveAgent:
    def __init__(self, current_settings):
        provider = PROVIDER_MAP.get(current_settings.provider.strip().lower())
        if not provider:
            raise AgentUnavailableError(
                "不支持的 Provider；请选择 openai-compatible、openai 或 deepseek"
            )
        model = init_model(
            provider=provider,
            model_name=current_settings.model,
            api_key=current_settings.api_key,
            api_base=current_settings.base_url,
        )
        self._agent = ReActAgent(
            AgentCard(
                name="city_sanitation_agent",
                description=(
                    "市容环卫综合乱象检测智能体。你能识别12类市容环卫问题："
                    "游摊、门店超范围经营、垃圾桶沿街摆放、垃圾桶脏污、垃圾混投、"
                    "垃圾桶不规范、垃圾乱堆、垃圾冒装、地面不洁、垃圾桶无分类标识、"
                    "垃圾桶破损、垃圾桶无序。"
                    "用户上传街景图片后，系统自动检测并返回乱象类别、位置和置信度。"
                    "你可以解释检测结果、提供处置建议、回答市容环卫相关问题。"
                ),
            )
        )
        self._agent.set_llm(model)

    async def answer(self, message: str, session_id: str, file_ids: list[str] | None = None) -> str:
        result = await self._agent.invoke({"query": message, "conversation_id": session_id})
        output = result.get("output") if isinstance(result, dict) else None
        if not isinstance(output, str) or not output.strip():
            raise AgentUnavailableError("模型没有返回可显示的回答")
        return output


def build_agent(current_settings) -> AgentAdapter:
    if current_settings.mode == "mock":
        return MockAgent()
    if not current_settings.configured:
        return UnavailableAgent()
    return OpenJiuwenLiveAgent(current_settings)


class AgentRuntime:
    def __init__(self, initial_settings):
        self._lock = RLock()
        self._settings = initial_settings
        self._agent = build_agent(initial_settings)

    @property
    def current_settings(self):
        with self._lock:
            return self._settings

    def prepare(self, next_settings) -> AgentAdapter:
        return build_agent(next_settings)

    def apply(self, next_settings, next_agent: AgentAdapter) -> None:
        with self._lock:
            self._settings = next_settings
            self._agent = next_agent

    async def answer(self, message: str, session_id: str, file_ids: list[str] | None = None) -> str:
        with self._lock:
            current_agent = self._agent
        return await current_agent.answer(message, session_id, file_ids)


runtime = AgentRuntime(settings)


async def answer(message: str, session_id: str, file_ids: list[str] | None = None) -> str:
    return await runtime.answer(message, session_id, file_ids)
