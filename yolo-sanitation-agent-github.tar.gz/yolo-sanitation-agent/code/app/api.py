# AI生成
from __future__ import annotations

from pathlib import Path
import subprocess
import sys
from uuid import uuid4

from fastapi import FastAPI, File, UploadFile, Form
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List

from .agent import AgentUnavailableError, answer, runtime
from .config import save_model_settings, updated_model_settings
from .detector import detect_image_bytes, model_status

# 检测统计计数器
_detection_stats = {"total_images": 0, "total_objects": 0, "by_class": {}, "by_scene": {}}

app = FastAPI(title="市容环卫检测智能体")
web_dir = Path(__file__).resolve().parent.parent / "web"
adapter_verifier = web_dir.parent / "scripts" / "verify-openjiuwen-adapter.py"
uploaded_files: dict[str, dict[str, object]] = {}
MAX_UPLOAD_BYTES = 20 * 1024 * 1024
ALLOWED_DOC_EXTENSIONS = {".txt", ".md", ".csv", ".json", ".pdf", ".docx"}
ALLOWED_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None
    file_ids: list[str] = []


class ModelConfigRequest(BaseModel):
    provider: str = "openai-compatible"
    model: str
    base_url: str = ""
    api_key: str | None = None


class DetectRequest(BaseModel):
    conf: float = 0.25
    iou: float = 0.45
    imgsz: int = 512


def config_status_body(current_settings) -> dict[str, object]:
    return {
        "provider": current_settings.provider,
        "model": current_settings.model,
        "base_url": current_settings.base_url,
        "mode": current_settings.mode,
        "configured": current_settings.configured,
        "has_api_key": bool(current_settings.api_key),
        "missing": current_settings.missing,
    }


def verify_live_adapter() -> str | None:
    result = subprocess.run(
        [sys.executable, str(adapter_verifier), "--agent", str(web_dir.parent / "app" / "agent.py")],
        cwd=web_dir.parent,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode == 0:
        return None
    return "模型适配器未通过当前 SDK 兼容性校验，请检查 Provider 映射、init_model 参数和 ReActAgent 调用方式"


@app.get("/health")
def health() -> dict[str, object]:
    return {"status": "ok", "mode": runtime.current_settings.mode, "sdk": "openjiuwen"}


@app.get("/ready")
def ready() -> JSONResponse:
    current_settings = runtime.current_settings
    body = {"status": "ready" if current_settings.configured else "not_ready", "mode": current_settings.mode, "configured": current_settings.configured}
    return JSONResponse(body, status_code=200 if current_settings.configured else 503)


@app.get("/config/status")
def config_status() -> dict[str, object]:
    return config_status_body(runtime.current_settings)


@app.get("/api/model/status")
def get_model_status() -> dict[str, object]:
    return model_status()


@app.put("/api/config/model")
def update_model_config(request: ModelConfigRequest) -> JSONResponse:
    try:
        next_settings = updated_model_settings(
            runtime.current_settings,
            provider=request.provider,
            model=request.model,
            base_url=request.base_url,
            api_key=request.api_key,
        )
        adapter_error = verify_live_adapter()
        if adapter_error:
            return JSONResponse({"status": "error", "code": "model_adapter_init_failed", "message": adapter_error}, status_code=422)
        next_agent = runtime.prepare(next_settings)
    except ValueError as exc:
        return JSONResponse({"status": "error", "code": "invalid_model_config", "message": str(exc)}, status_code=400)
    except AgentUnavailableError as exc:
        return JSONResponse({"status": "error", "code": "invalid_model_config", "message": str(exc)}, status_code=400)
    except Exception:
        return JSONResponse({"status": "error", "code": "model_adapter_init_failed", "message": "模型初始化失败：请检查 Provider、模型名、Base URL 和 API Key"}, status_code=422)
    try:
        save_model_settings(next_settings)
    except OSError:
        return JSONResponse({"status": "error", "code": "model_config_save_failed", "message": "Unable to save model settings"}, status_code=500)
    runtime.apply(next_settings, next_agent)
    return JSONResponse(config_status_body(next_settings))


@app.post("/api/chat")
async def chat(request: ChatRequest) -> JSONResponse:
    message = request.message.strip()
    if not message:
        return JSONResponse({"status": "error", "code": "invalid_request", "message": "message is required"}, status_code=400)
    session_id = request.session_id or str(uuid4())
    try:
        return JSONResponse({"status": "ok", "answer": await answer(message, session_id, request.file_ids), "session_id": session_id})
    except AgentUnavailableError as exc:
        return JSONResponse({"status": "error", "code": "agent_unavailable", "message": str(exc)}, status_code=503)
    except Exception:
        return JSONResponse({"status": "error", "code": "agent_error", "message": "Agent request failed"}, status_code=500)


@app.post("/api/files")
async def upload_file(file: UploadFile = File(...)) -> JSONResponse:
    name = Path(file.filename or "").name
    suffix = Path(name).suffix.lower()
    if not name or suffix not in (ALLOWED_DOC_EXTENSIONS | ALLOWED_IMAGE_EXTENSIONS):
        return JSONResponse({"status": "error", "code": "invalid_file", "message": "Unsupported file type"}, status_code=400)
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        return JSONResponse({"status": "error", "code": "file_too_large", "message": "File exceeds 20 MB limit"}, status_code=413)
    file_id = str(uuid4())
    uploaded_files[file_id] = {"name": name, "size": len(content), "content_type": file.content_type or "", "content": content}
    return JSONResponse({"status": "ok", "file_id": file_id, "name": name, "size": len(content), "content_type": file.content_type or "", "is_image": suffix in ALLOWED_IMAGE_EXTENSIONS})


@app.post("/api/detect")
async def detect(file: UploadFile = File(...), conf: float = 0.25, iou: float = 0.45, imgsz: int = 416) -> JSONResponse:
    """对上传图片执行市容环卫乱象检测，返回检测结果与可视化图。"""
    content = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(content) > MAX_UPLOAD_BYTES:
        return JSONResponse({"status": "error", "code": "file_too_large", "message": "图片超过 20 MB 限制"}, status_code=413)
    if not content:
        return JSONResponse({"status": "error", "code": "invalid_image", "message": "未收到图片数据"}, status_code=400)
    result = detect_image_bytes(content, conf=conf, iou=iou, imgsz=imgsz, draw=True)
    result["filename"] = Path(file.filename or "").name
    # 更新统计
    if result.get("status") == "ok":
        _detection_stats["total_images"] += 1
        _detection_stats["total_objects"] += result["num_objects"]
        for o in result["objects"]:
            _detection_stats["by_class"][o["category"]] = _detection_stats["by_class"].get(o["category"], 0) + 1
            sc = o.get("scene", "其他")
            _detection_stats["by_scene"][sc] = _detection_stats["by_scene"].get(sc, 0) + 1
    return JSONResponse(result)


@app.post("/api/detect/batch")
async def detect_batch(files: List[UploadFile] = File(...), conf: float = 0.25, iou: float = 0.45, imgsz: int = 416) -> JSONResponse:
    """批量检测多张图片，返回每张图片的检测结果（不含可视化图以节省带宽）。"""
    results = []
    for f in files:
        content = await f.read(MAX_UPLOAD_BYTES + 1)
        if len(content) > MAX_UPLOAD_BYTES:
            results.append({"filename": Path(f.filename or "").name, "status": "error", "message": "图片超过 20 MB 限制"})
            continue
        if not content:
            results.append({"filename": Path(f.filename or "").name, "status": "error", "message": "未收到图片数据"})
            continue
        r = detect_image_bytes(content, conf=conf, iou=iou, imgsz=imgsz, draw=False)
        r["filename"] = Path(f.filename or "").name
        if r.get("status") == "ok":
            _detection_stats["total_images"] += 1
            _detection_stats["total_objects"] += r["num_objects"]
            for o in r["objects"]:
                _detection_stats["by_class"][o["category"]] = _detection_stats["by_class"].get(o["category"], 0) + 1
                sc = o.get("scene", "其他")
                _detection_stats["by_scene"][sc] = _detection_stats["by_scene"].get(sc, 0) + 1
        results.append(r)
    return JSONResponse({"status": "ok", "count": len(results), "results": results})


@app.get("/api/stats")
def get_stats() -> dict[str, object]:
    """返回检测统计信息。"""
    return _detection_stats


app.mount("/", StaticFiles(directory=web_dir, html=True), name="web")
