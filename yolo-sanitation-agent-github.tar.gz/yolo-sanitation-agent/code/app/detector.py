# AI生成
"""市容环卫乱象检测器：封装 YOLOv8 推理，供 Agent Web 应用调用。

模型加载策略（按优先级）：
    1. code/models/best.pt          — 随作品分发的微调权重
    2. work/runs/train/weights/best.pt — 训练产物（开发期）
    3. yolov8s.pt                    — 赛事基座模型（兜底）
"""
from __future__ import annotations

import base64
import os
import threading
from typing import Any

import cv2
import numpy as np

from .config import settings  # noqa: F401  确保 config 可用

_LOCK = threading.Lock()
_MODEL: Any = None
_MODEL_PATH: str | None = None

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PROJECT_ROOT = os.path.dirname(_ROOT)

# 从 common.py 导入统一定义
import sys as _sys
_sys.path.insert(0, _ROOT)
from common import PER_CLASS_CONF, CLASS_TO_SCENE  # noqa: E402

_CANDIDATE_MODELS = [
    os.path.join(_ROOT, "models", "best.pt"),
    os.path.join(_PROJECT_ROOT, "work", "runs", "train_opt", "weights", "best.pt"),
    os.path.join(_PROJECT_ROOT, "work", "runs", "train", "weights", "best.pt"),
    os.path.join(_PROJECT_ROOT, "yolov8s.pt"),
]


def _resolve_model_path() -> str | None:
    for path in _CANDIDATE_MODELS:
        if os.path.isfile(path):
            return path
    return None


def get_model():
    """惰性加载并缓存 YOLO 模型（线程安全）。"""
    global _MODEL, _MODEL_PATH
    with _LOCK:
        if _MODEL is not None:
            return _MODEL, _MODEL_PATH
        path = _resolve_model_path()
        if path is None:
            return None, None
        from ultralytics import YOLO
        _MODEL = YOLO(path)
        _MODEL_PATH = path
        return _MODEL, _MODEL_PATH


def model_status() -> dict[str, Any]:
    model, path = get_model()
    return {
        "loaded": model is not None,
        "model_path": os.path.basename(path) if path else None,
        "classes": list(model.names.values()) if model is not None else [],
    }


def _scene_of(category: str) -> str:
    return CLASS_TO_SCENE.get(category, "其他")


def detect_image_bytes(
    data: bytes,
    conf: float = 0.25,
    iou: float = 0.45,
    imgsz: int = 416,
    draw: bool = True,
) -> dict[str, Any]:
    """对一张图片字节执行检测，返回结构化结果与可视化图（base64 JPEG）。

    优化策略：用全局低阈值 (0.01) 获取所有候选框，再按 PER_CLASS_CONF 后处理过滤。
    bbox 统一为左上角约定 [x_left, y_top, width, height]（与赛题 result.json 一致）。
    """
    model, _ = get_model()
    if model is None:
        return {"status": "error", "code": "model_not_found", "message": "未找到可用模型权重"}

    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        return {"status": "error", "code": "invalid_image", "message": "无法解码图片"}

    h, w = img.shape[:2]
    # 全局低阈值获取候选框，后处理按分类别阈值过滤
    results = model.predict(source=img, conf=0.01, iou=iou, imgsz=imgsz, device="cpu", verbose=False)
    r = results[0]

    objects = []
    if r.boxes is not None and len(r.boxes) > 0:
        xyxy = r.boxes.xyxy.cpu().numpy()  # [x1, y1, x2, y2] 像素
        confs = r.boxes.conf.cpu().numpy()
        clss = r.boxes.cls.cpu().numpy().astype(int)
        names = model.names
        for i in range(len(xyxy)):
            x1, y1, x2, y2 = xyxy[i]
            bw, bh = x2 - x1, y2 - y1
            cat = names.get(int(clss[i]), str(int(clss[i])))
            score = float(confs[i])
            # 分类别置信度过滤
            cls_threshold = PER_CLASS_CONF.get(cat, conf)
            if score < cls_threshold:
                continue
            objects.append({
                "category": cat,
                "bbox": [round(float(x1), 1), round(float(y1), 1), round(float(bw), 1), round(float(bh), 1)],
                "score": round(score, 4),
                "scene": _scene_of(cat),
            })

    annotated_b64 = None
    if draw:
        # 手绘过滤后的框（而非 r.plot() 会画所有候选框）
        plotted = img.copy()
        _COLORS = [
            (0, 0, 255), (0, 255, 0), (255, 0, 0), (0, 255, 255),
            (255, 0, 255), (255, 255, 0), (128, 0, 255), (0, 128, 255),
            (255, 128, 0), (128, 255, 0), (255, 0, 128), (0, 255, 128),
        ]
        for o in objects:
            bx, by, bw, bh = o["bbox"]
            cat = o["category"]
            cls_id = 0
            for i, name in enumerate(model.names.values()):
                if name == cat:
                    cls_id = i
                    break
            color = _COLORS[cls_id % len(_COLORS)]
            x1, y1 = int(bx), int(by)
            x2, y2 = int(bx + bw), int(by + bh)
            cv2.rectangle(plotted, (x1, y1), (x2, y2), color, 2)
            label = f"{cat} {o['score']:.2f}"
            (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            cv2.rectangle(plotted, (x1, y1 - th - 6), (x1 + tw + 2, y1), color, -1)
            cv2.putText(plotted, label, (x1 + 1, y1 - 4), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        ok, buf = cv2.imencode(".jpg", plotted, [cv2.IMWRITE_JPEG_QUALITY, 85])
        if ok:
            annotated_b64 = base64.b64encode(buf.tobytes()).decode("ascii")

    by_scene: dict[str, int] = {}
    for o in objects:
        by_scene[o["scene"]] = by_scene.get(o["scene"], 0) + 1

    return {
        "status": "ok",
        "image_width": int(w),
        "image_height": int(h),
        "num_objects": len(objects),
        "objects": objects,
        "scene_summary": by_scene,
        "annotated_image": annotated_b64,
    }
