from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Mapping

from dotenv import dotenv_values

ENV_FILE = Path(__file__).resolve().parent.parent / ".env"
@dataclass(frozen=True)
class Settings:
    mode: str = "mock"
    provider: str = ""
    model: str = ""
    api_key: str = ""
    base_url: str = ""
    host: str = "127.0.0.1"
    port: int = 8000

    @property
    def configured(self) -> bool:
        return self.mode == "mock" or bool(self.provider and self.model and self.api_key and self.base_url)

    @property
    def missing(self) -> list[str]:
        if self.mode == "mock":
            return []
        required = {
            "AGENT_MODEL_PROVIDER": self.provider,
            "AGENT_MODEL_NAME": self.model,
            "AGENT_MODEL_API_KEY": self.api_key,
            "AGENT_MODEL_BASE_URL": self.base_url,
        }
        return [name for name, value in required.items() if not value]


def _environment_values() -> dict[str, str]:
    values = dict(os.environ)
    if ENV_FILE.is_file():
        values.update({key: value for key, value in dotenv_values(ENV_FILE).items() if value is not None})
    return values


def load_settings(values: Mapping[str, str] | None = None) -> Settings:
    source = values if values is not None else _environment_values()
    try:
        port = int(source.get("PORT", "8000"))
    except ValueError:
        port = 8000
    return Settings(
        mode=source.get("AGENT_MODE", "mock").lower(),
        provider=source.get("AGENT_MODEL_PROVIDER", ""),
        model=source.get("AGENT_MODEL_NAME", ""),
        api_key=source.get("AGENT_MODEL_API_KEY", ""),
        base_url=source.get("AGENT_MODEL_BASE_URL", ""),
        host=source.get("HOST", "127.0.0.1"),
        port=port,
    )


def updated_model_settings(
    current: Settings,
    *,
    provider: str,
    model: str,
    base_url: str,
    api_key: str | None,
) -> Settings:
    values = [provider, model, base_url, api_key or ""]
    if any("\n" in value or "\r" in value for value in values):
        raise ValueError("Model settings must not contain line breaks")
    next_provider = provider.strip() or current.provider or "openai-compatible"
    next_model = model.strip()
    next_key = api_key.strip() if api_key and api_key.strip() else current.api_key
    next_base_url = base_url.strip()
    if not next_model or not next_key or not next_base_url:
        raise ValueError("Model name, API Base URL and API Key are required")
    return Settings(
        mode="live",
        provider=next_provider,
        model=next_model,
        api_key=next_key,
        base_url=next_base_url,
        host=current.host,
        port=current.port,
    )


def _quote_env(value: str) -> str:
    return '"' + value.replace("\\", "\\\\").replace('"', '\\"') + '"'


def save_model_settings(settings: Settings) -> None:
    updates = {
        "AGENT_MODE": settings.mode,
        "AGENT_MODEL_PROVIDER": settings.provider,
        "AGENT_MODEL_NAME": settings.model,
        "AGENT_MODEL_API_KEY": settings.api_key,
        "AGENT_MODEL_BASE_URL": settings.base_url,
    }
    source = ENV_FILE.read_text(encoding="utf-8") if ENV_FILE.exists() else ""
    output: list[str] = []
    written: set[str] = set()
    for line in source.splitlines(keepends=True):
        name, separator, _ = line.lstrip().partition("=")
        name = name.strip()
        if separator and name in updates:
            output.append(f"{name}={_quote_env(updates[name])}\n")
            written.add(name)
        else:
            output.append(line)
    if output and not output[-1].endswith("\n"):
        output.append("\n")
    for name, value in updates.items():
        if name not in written:
            output.append(f"{name}={_quote_env(value)}\n")
    ENV_FILE.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", newline="\n", dir=ENV_FILE.parent, delete=False) as handle:
        handle.writelines(output)
        temporary_path = Path(handle.name)
    try:
        os.replace(temporary_path, ENV_FILE)
    finally:
        if temporary_path.exists():
            temporary_path.unlink(missing_ok=True)


settings = load_settings()
